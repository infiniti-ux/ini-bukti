import re
import struct
import sys

f = sys.argv[1] if len(sys.argv) > 1 else "tinytrace.exe"
d = open(f, "rb").read()

# baca header PE biar bisa map rva ke offset file
pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

# tabel addend di .rdata (0x19360), polanya 13 29 13 29 ...
t2 = d[off(0x19360):off(0x19360) + 0x20]

# ambil 16 mov dword di worker mulai rva 0x1571 -> 64 byte target (x + y)
code = d[off(0x1571):off(0x1571) + 0x80]
movs = re.findall(rb"\xc7\x45.(....)", code, re.S)
blob = b"".join(m for m in movs)
x, y = blob[:0x20], blob[0x20:]

# tiap byte: (x[j] ^ input[j]) + t2[j] == y[j]
flag = bytes(x[j] ^ ((y[j] - t2[j]) & 0xFF) for j in range(32))
print(flag.decode())
