import re
import secrets
import socket

HOST, PORT = "165.22.100.192", 30232


def attempt():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    f = s.makefile("rb")
    buf = b""
    while b"commitment" not in buf:
        buf += f.readline()
    txt = buf.decode()
    p = int(re.search(r"p \(modulus\) is (\d+)", txt).group(1))
    g = int(re.search(r"where g is (\d+)", txt).group(1))
    y = int(re.search(r"public key is (\d+)", txt).group(1))

    guess = secrets.randbelow(5) + 1
    z = secrets.randbelow(p - 2) + 1
    r = pow(g, z, p) * pow(y, -guess, p) % p

    s.sendall(str(r).encode() + b"\n")
    buf = b""
    while b"challenge number" not in buf:
        buf += f.readline()
    e = int(re.search(r"e = (\d+)", buf.decode()).group(1))

    if e != guess:
        s.close()
        return None
    s.sendall(str(z).encode() + b"\n")
    buf = b""
    while True:
        line = f.readline()
        if not line:
            break
        buf += line
        if b"flag" in buf.lower() or b"bye" in buf.lower():
            break
    s.close()
    return buf.decode(errors="replace")


for i in range(200):
    out = attempt()
    if out is None:
        continue
    print(f"try {i}: {out.strip()}")
    m = re.search(r"JCC\{[^}]+\}", out)
    if m:
        print("FLAG:", m.group(0))
        break
    if i % 20 == 19:
        print(f"...{i + 1} tries so far")
