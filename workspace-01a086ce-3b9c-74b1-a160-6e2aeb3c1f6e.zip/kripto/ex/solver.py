import base64
import sys

f = sys.argv[1] if len(sys.argv) > 1 else "flag.txt"
s = open(f).read().strip()

s = base64.b64decode(s).decode()

out = []
for c in s:
    if "a" <= c <= "z":
        out.append(chr((ord(c) - 97 - 7) % 26 + 97))
    elif "A" <= c <= "Z":
        out.append(chr((ord(c) - 65 - 7) % 26 + 65))
    else:
        out.append(c)
print("".join(out))
