import json
import socket
import sys
import time

HOST, PORT = "165.22.100.192", 31674
KNOWN = b"STATUS_REPORT___" + b"\x00" * (320 - 16)


def setup():
    s = socket.create_connection((HOST, PORT), timeout=15)
    s.settimeout(15)
    f = s.makefile("rb")
    f.readline()
    s.sendall((json.dumps({"option": "encrypt"}) + "\n").encode())
    r = json.loads(f.readline())
    return s, f, bytearray(bytes.fromhex(r["ciphertext"])), r["tag"]


def q(c, ct, tag):
    m = bytearray(ct)
    b19 = int.from_bytes(m[18 * 16:19 * 16], "big") ^ 1
    b20 = int.from_bytes(m[19 * 16:20 * 16], "big") ^ c
    m[18 * 16:19 * 16] = b19.to_bytes(16, "big")
    m[19 * 16:20 * 16] = b20.to_bytes(16, "big")
    return json.dumps({"option": "execute", "ciphertext": bytes(m).hex(), "tag": tag}) + "\n"


def scan_range(s, f, ct, tag, cfrom, cto):
    for c in range(cfrom, cto):
        s.sendall(q(c, ct, tag).encode())
    hits = []
    for c in range(cfrom, cto):
        line = f.readline()
        if not line:
            break
        if b"unrecognised" in line:
            hits.append(c)
    return hits


s1, f1, ct1, tag1 = setup()
s2, f2, ct2, tag2 = setup()
print("two conns ready", file=sys.stderr)

# keystream & structural candidates on conn1
ks1 = bytes(a ^ b for a, b in zip(ct1, KNOWN))
cands = []
for i in range(20):
    cands.append(int.from_bytes(ks1[i * 16:(i + 1) * 16], "big"))
cands += [int.from_bytes(ks1[:12], "big"), 0, 1, 0xE1 << 120, 2, 3]
seen = set()
t0 = time.time()
for c in cands:
    if c in seen or c == 0:
        continue
    seen.add(c)
    s1.sendall(q(c, ct1, tag1).encode())
hits = []
for c in cands:
    if c == 0:
        continue
    line = f1.readline()
    if b"unrecognised" in line:
        hits.append(c)
print("keystream/structural candidates:", hits, f"{time.time()-t0:.1f}s", file=sys.stderr)

# parallel scan 1..4000 on both connections
h1 = scan_range(s1, f1, ct1, tag1, 1, 4000)
h2 = scan_range(s2, f2, ct2, tag2, 1, 4000)
print("conn1 hits 1..4000:", h1, file=sys.stderr)
print("conn2 hits 1..4000:", h2, file=sys.stderr)
s1.close()
s2.close()
