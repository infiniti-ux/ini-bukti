import json
import socket
import sys
import time

import os
import sys

HOST = os.environ.get("PHOST", "165.22.100.192")
PORT = int(os.environ.get("PPORT", "31674"))
KNOWN = b"STATUS_REPORT___" + b"\x00" * (320 - 16)
R_POLY = 0xE1 << 120


def gf_mul(x, y):
    z = 0
    v = y
    for i in range(128):
        if (x >> (127 - i)) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ R_POLY
        else:
            v >>= 1
    return z


def setup():
    for _ in range(10):
        try:
            s = socket.create_connection((HOST, PORT), timeout=20)
            s.settimeout(20)
            f = s.makefile("rb")
            f.readline()
            s.sendall((json.dumps({"option": "encrypt"}) + "\n").encode())
            r = json.loads(f.readline())
            ct = bytes.fromhex(r["ciphertext"])
            tag = r["tag"]
            return s, f, ct, tag
        except Exception as e:
            print("setup retry:", e, file=sys.stderr)
            time.sleep(1)
    sys.exit(4)


def build_deltas(cands):
    # P(X) = X^2 * prod(X + c) -> coefficients for exponents 2..21
    # ring identity in this bit-reversed representation is 1<<127
    poly = [1 << 127]  # q(X) = prod(X + c), index j -> coeff of X^j
    for c in cands:
        new = [0] * (len(poly) + 1)
        for j, v in enumerate(poly):
            new[j] ^= gf_mul(v, c)   # c*q_j -> X^j
            new[j + 1] ^= v          # q_j -> X^{j+1}
        poly = new
    # P(X) = X^2 * q(X): coeff of X^(2+k) is poly[k]  (k=0 -> X^2 term... wait)
    # q has degree m: coeff poly[k] of X^k; P coeff of X^e (e=2..m+2) = poly[e-2]
    deltas = {}
    for k, v in enumerate(poly):
        if v:
            exp = 2 + k
            blk = 22 - exp  # ct block index 1..20 (exponent e <-> block 22-e)
            deltas[blk] = v
    return deltas


def tweak(ct, deltas):
    m = bytearray(ct)
    for blk, v in deltas.items():
        i = (blk - 1) * 16
        cur = int.from_bytes(m[i:i + 16], "big") ^ v
        m[i:i + 16] = cur.to_bytes(16, "big")
    return bytes(m)


def query(s, ct, tag, deltas):
    m = tweak(ct, deltas)
    s.sendall((json.dumps({"option": "execute", "ciphertext": m.hex(), "tag": tag}) + "\n").encode())


def read_resp(f):
    return f.readline()


def scan_one_connection():
    s, f, ct, tag = setup()
    print("ready on fresh connection", file=sys.stderr)

    # quick sanity: individual small/structural candidates first (correct root test)
    struct_cands = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 31, 32, 0xE1 << 120]
    for c in struct_cands:
        query(s, ct, tag, build_deltas([c]))
    for c in struct_cands:
        line = read_resp(f)
        if b"unrecognised" in line:
            print("HIT c =", hex(c), file=sys.stderr)
            with open("h_found.txt", "w") as fh:
                fh.write(hex(c))
            return c, s, f, ct, tag

    # batched scan, 19 candidates per query
    BATCH = 19
    lo = 1
    t0 = time.time()
    nq = 0
    while True:
        cands = list(range(lo, lo + BATCH))
        query(s, ct, tag, build_deltas(cands))
        nq += 1
        line = read_resp(f)
        if not line:
            print("connection closed at lo=", lo, file=sys.stderr)
            s.close()
            return None
        if b"unrecognised" in line:
            print("BATCH HIT around lo =", lo, file=sys.stderr)
            for c in cands:
                query(s, ct, tag, build_deltas([c]))
            for c in cands:
                line = read_resp(f)
                if b"unrecognised" in line:
                    print("H =", hex(c), file=sys.stderr)
                    with open("h_found.txt", "w") as fh:
                        fh.write(hex(c))
                    return c, s, f, ct, tag
            print("(only zero root?)", file=sys.stderr)
            with open("h_found.txt", "w") as fh:
                fh.write("0")
            return 0, s, f, ct, tag
        lo += BATCH
        if nq % 5000 == 0:
            print(f"scanning ... lo={lo} ({nq}q, {time.time()-t0:.0f}s, {nq/(time.time()-t0):.0f} q/s)", file=sys.stderr)
        if lo >= (1 << 26):
            print("gave up this connection at 2^26", file=sys.stderr)
            s.close()
            return None


if __name__ == "__main__":
    while True:
        try:
            r = scan_one_connection()
            if r:
                sys.exit(0)
        except Exception as e:
            print("conn error:", e, file=sys.stderr)
            time.sleep(1)
