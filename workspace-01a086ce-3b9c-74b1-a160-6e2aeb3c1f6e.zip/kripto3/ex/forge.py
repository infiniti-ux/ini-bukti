import json
import os
import socket
import sys
import struct

HOST = os.environ.get("PHOST", "165.22.100.192")
PORT = int(os.environ.get("PPORT", "31674"))
KNOWN = b"STATUS_REPORT___"
TARGET = b"GIVEMETHEFLAG___"
MSG_LEN = 320
R_POLY = 0xE1 << 120


def gf_mul(x, y):
    z = 0
    v = y
    for i in range(128):
        if (x >> (127 - i)) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ R_POLY
        else:
            v >>= 1
    return z


def ghash(H, blocks):
    y = 0
    for b in blocks:
        y = gf_mul(y ^ b, H)
    return y


def tag_for(H, mask, ct):
    blocks = [int.from_bytes(ct[i:i + 16], "big") for i in range(0, len(ct), 16)]
    len_block = int.from_bytes(struct.pack(">QQ", 0, len(ct) * 8), "big")
    blocks.append(len_block)
    return (ghash(H, blocks) ^ mask).to_bytes(16, "big")


def main(h_hex):
    H = int(h_hex, 16)
    s = socket.create_connection((HOST, PORT), timeout=20)
    s.settimeout(20)
    f = s.makefile("rb")
    f.readline()
    s.sendall((json.dumps({"option": "encrypt"}) + "\n").encode())
    r = json.loads(f.readline())
    ct = bytes.fromhex(r["ciphertext"])
    tag = bytes.fromhex(r["tag"])

    # recover mask from known pair
    blocks = [int.from_bytes(ct[i:i + 16], "big") for i in range(0, MSG_LEN, 16)]
    len_block = int.from_bytes(struct.pack(">QQ", 0, MSG_LEN * 8), "big")
    blocks.append(len_block)
    mask = int.from_bytes(tag, "big") ^ ghash(H, blocks)

    # forge: block1 plaintext = TARGET, rest unchanged (zeros)
    delta = bytes(a ^ b for a, b in zip(KNOWN, TARGET))
    ct2 = bytearray(ct)
    ct2[:16] = bytes(a ^ b for a, b in zip(ct2[:16], delta))
    ct2 = bytes(ct2)
    tag2 = tag_for(H, mask, ct2)

    req = {"option": "execute", "ciphertext": ct2.hex(), "tag": tag2.hex()}
    s.sendall((json.dumps(req) + "\n").encode())
    out = b""
    while True:
        line = f.readline()
        if not line:
            break
        out += line
        if b"JCC{" in out or b"bye" in line.lower():
            break
    print(out.decode(errors="replace"))
    s.close()


if __name__ == "__main__":
    h = sys.argv[1] if len(sys.argv) > 1 else open("h_found.txt").read().strip()
    main(h)
