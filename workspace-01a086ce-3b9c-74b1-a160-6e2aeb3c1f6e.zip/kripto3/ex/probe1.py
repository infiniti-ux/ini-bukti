import json
import socket
import struct
import sys
import time

HOST, PORT = "165.22.100.192", 31674
KNOWN = b"STATUS_REPORT___" + b"\x00" * (320 - 16)

s = socket.create_connection((HOST, PORT), timeout=15)
s.settimeout(15)
f = s.makefile("rb")
f.readline()  # banner
s.sendall((json.dumps({"option": "encrypt"}) + "\n").encode())
r = json.loads(f.readline())
ct = bytearray(bytes.fromhex(r["ciphertext"]))
tag = r["tag"]
print("connected, ct/tag ready; tag:", tag, file=sys.stderr)

def query_for_c(c, base_ct, base_tag):
    # tweak blocks 19 & 20 (indices 18,19): P(X)=X^3 + c*X^2 = X^2(X+c)
    m = bytearray(base_ct)
    b19 = int.from_bytes(m[18 * 16:19 * 16], "big") ^ 1
    b20 = int.from_bytes(m[19 * 16:20 * 16], "big") ^ c
    m[18 * 16:19 * 16] = b19.to_bytes(16, "big")
    m[19 * 16:20 * 16] = b20.to_bytes(16, "big")
    return json.dumps({"option": "execute", "ciphertext": bytes(m).hex(), "tag": base_tag}) + "\n"

# throughput test: 200 pipelined queries for c=1..200
N = 200
t0 = time.time()
for c in range(1, N + 1):
    s.sendall(query_for_c(c, ct, tag).encode())
ok = 0
for _ in range(N):
    line = f.readline()
    if not line:
        break
    if b"unrecognised" in line:
        ok += 1
dt = time.time() - t0
print(f"pipelined {N} queries in {dt:.2f}s -> {N/dt:.0f} q/s, hits={ok}", file=sys.stderr)
s.close()
