/* pure asm replication of chall main to dump regs at shellcode entry */
#include <sys/mman.h>
#include <unistd.h>
#include <stdio.h>

extern long do_read(int fd, void *buf, unsigned long n);
extern void *do_mmap(void *addr, unsigned long len, int prot, int flags, int fd, long off);

static unsigned long saved[18]; /* rax rbx rcx rdx rsi rdi rbp rsp r8 r9 r10 r11 r12 r13 r14 r15 rip flag */

__asm__(
".intel_syntax noprefix\n"
".text\n"
"do_read:\n"
"    mov eax, 0\n"
"    syscall\n"
"    ret\n"
"do_mmap:\n"
"    mov r10, rcx\n"
"    mov eax, 9\n"
"    syscall\n"
"    ret\n"
".att_syntax\n");

int main(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  char buf[7] = {0};
  puts("h2");
  ssize_t n = do_read(0, buf, 6);
  void *sc = do_mmap(0, 0x1000, 7, 0x22, -1, 0);
  /* replicate chall's dword copies */
  *(unsigned int*)((char*)sc + 0) = *(unsigned int*)(buf + 0);
  *(unsigned int*)((char*)sc + 3) = *(unsigned int*)(buf + 3);

  __asm__(".intel_syntax noprefix\n"
      "mov [rip+saved+0],  rax\n"
      "mov [rip+saved+8],  rbx\n"
      "mov [rip+saved+16], rcx\n"
      "mov [rip+saved+24], rdx\n"
      "mov [rip+saved+32], rsi\n"
      "mov [rip+saved+40], rdi\n"
      "mov [rip+saved+48], rbp\n"
      "mov [rip+saved+56], rsp\n"
      "mov [rip+saved+64], r8\n"
      "mov [rip+saved+72], r9\n"
      "mov [rip+saved+80], r10\n"
      "mov [rip+saved+88], r11\n"
      "mov [rip+saved+96], r12\n"
      "mov [rip+saved+104], r13\n"
      "mov [rip+saved+112], r14\n"
      "mov [rip+saved+120], r15\n"
      ".att_syntax\n");
  printf("n=%zd sc=%p buf=%p\n", n, sc, buf);
  const char *names[] = {"rax","rbx","rcx","rdx","rsi","rdi","rbp","rsp","r8","r9","r10","r11","r12","r13","r14","r15"};
  for (int i = 0; i < 16; i++) printf("%s=%#lx ", names[i], saved[i]);
  printf("\n");
  return 0;
}
