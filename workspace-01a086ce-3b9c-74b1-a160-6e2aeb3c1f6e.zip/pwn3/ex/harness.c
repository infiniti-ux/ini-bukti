// replicate main() exactly to capture register state at shellcode entry
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>

struct regdump { uint64_t rax,rbx,rcx,rdx,rsi,rdi,rbp,rsp,r8,r9,r10,r11,r12,r13,r14,r15,rip; };
static struct regdump rd;

int main(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  char buf[7] = {0};
  puts("harness");
  ssize_t n = read(0, buf, sizeof(buf) - 1);
  void *sc = mmap(0, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC,
                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sc == MAP_FAILED) { puts("mmap fail"); _exit(1); }
  // replicate exact dword-copy block of main
  __asm__ volatile(
      "mov %[sc], %%rax\n\t"
      "mov (%[buf]), %%edx\n\t"
      "mov %%edx, (%%rax)\n\t"
      "mov 3(%[buf]), %%edx\n\t"
      "mov %%edx, 3(%%rax)\n\t"
      "mov %%rax, %%rbx\n\t"          // keep sc
      "mov %%rax, %[rd_rax]\n\t"
      "mov %%rdx, %[rd_rdx]\n\t"
      "mov %%rcx, %[rd_rcx]\n\t"
      "mov %%rsi, %[rd_rsi]\n\t"
      "mov %%rdi, %[rd_rdi]\n\t"
      "mov %%rsp, %[rd_rsp]\n\t"
      "mov %%rbp, %[rd_rbp]\n\t"
      "mov %%r8,  %[rd_r8]\n\t"
      "mov %%r9,  %[rd_r9]\n\t"
      "mov %%r10, %[rd_r10]\n\t"
      "mov %%r11, %[rd_r11]\n\t"
      "mov %%r12, %[rd_r12]\n\t"
      "mov %%r13, %[rd_r13]\n\t"
      "mov %%r14, %[rd_r14]\n\t"
      "mov %%r15, %[rd_r15]\n\t"
      : [rd_rax]"=m"(rd.rax),[rd_rdx]"=m"(rd.rdx),[rd_rcx]"=m"(rd.rcx),
        [rd_rsi]"=m"(rd.rsi),[rd_rdi]"=m"(rd.rdi),[rd_rsp]"=m"(rd.rsp),
        [rd_rbp]"=m"(rd.rbp),[rd_r8]"=m"(rd.r8),[rd_r9]"=m"(rd.r9),
        [rd_r10]"=m"(rd.r10),[rd_r11]"=m"(rd.r11),[rd_r12]"=m"(rd.r12),
        [rd_r13]"=m"(rd.r13),[rd_r14]"=m"(rd.r14),[rd_r15]"=m"(rd.r15)
      : [sc]"r"(sc), [buf]"r"(buf)
      : "rax","rdx","rbx","memory");
  printf("sc=%p buf=%p n=%zd\n", sc, buf, n);
  printf("rax=%#lx rbx=%#lx rcx=%#lx rdx=%#lx\n", rd.rax, rd.rbx, rd.rcx, rd.rdx);
  printf("rsi=%#lx rdi=%#lx rbp=%#lx rsp=%#lx\n", rd.rsi, rd.rdi, rd.rbp, rd.rsp);
  printf("r8=%#lx r9=%#lx r10=%#lx r11=%#lx\n", rd.r8, rd.r9, rd.r10, rd.r11);
  printf("r12=%#lx r13=%#lx r14=%#lx r15=%#lx\n", rd.r12, rd.r13, rd.r14, rd.r15);
  return 0;
}
