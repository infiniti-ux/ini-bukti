#!/bin/bash
# Jalankan replika Queen Anne's Revenge di port 1337 (untuk screenshot lokal)
# Dependensi: socat + dukungan ELF 32-bit
#   Debian/Ubuntu: sudo apt install socat libc6-i386
#   (WSL juga bisa)
set -e
cd "$(dirname "$0")"

# flag.txt lokal (isi flag asli biar screenshot konsisten sama writeup)
printf 'JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}' > flag.txt
chmod +x chall

echo "[+] Replika jalan di 127.0.0.1:1337 ..."
echo "[+] Test: nc 127.0.0.1 1337   atau   python3 exploit_local.py"
echo "[+] Ctrl+C untuk stop"

# pty dipaksa biar output prompt live seperti remote asli
exec socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"./chall",pty,stderr,setsid,sigint,sane
