import struct
import sys

f = sys.argv[1] if len(sys.argv) > 1 else "Sudoku.exe"
d = open(f, "rb").read()

pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

blob = d[off(0x6000):off(0x6000) + 0x2A]

key = (7 * 0x539 + 13) & 0xFF
rev = blob[::-1]
flag = bytes(((b ^ key) >> 4 | (b ^ key) << 4) & 0xFF for b in rev)
print(flag.decode())
