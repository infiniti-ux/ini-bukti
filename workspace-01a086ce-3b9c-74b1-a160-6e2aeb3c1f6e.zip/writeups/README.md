# JCC 2026 Writeups

Kumpulan writeup challenge yang diselesaikan di kualifikasi JCC 2026.

| Challenge | Kategori | Flag |
|---|---|---|
| [tiny](tiny.md) | Reverse | `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}` |
| [Sudoku Master](sudoku.md) | Reverse | `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}` |
| [crypto-101](crypto-101.md) | Kripto | `JCC{W3lc0me_T0_Cryp706r4phy}` |
| [Za King's Perjury](za-kings-perjury.md) | Kripto | `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}` |
| [Queen Anne's Revenge](queen-annes-revenge.md) | Pwn | `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}` |
