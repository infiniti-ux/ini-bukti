# Za King's Perjury

Author: adieos — Kripto — 124 solves

Service remote (nc), diberikan `server.py`:

```python
P = <bilangan prima 1024-bit>
G = 2
Y = <public key>

e = secrets.randbelow(5) + 1   # challenge, cuma 1..5

# alur:
# 1. client kirim R
# 2. server kirim e
# 3. client kirim Z
# 4. kalau pow(G, Z, P) == (R * pow(Y, e, P)) % P -> FLAG
```

## Ringkasan

Server menjalankan protokol Schnorr: buktikan kamu tahu `x` dengan `Y = g^x mod p`, tanpa pernah mengirim `x`. Verifikasinya `g^Z == R * Y^e (mod p)`, dengan challenge `e` cuma diambil dari {1,2,3,4,5} — *setelah* client kirim commitment `R`.

Kita tidak tahu `x`, tapi karena ruang challenge kecil, tinggal tebak `e` duluan, commit `R = g^z * Y^(-e')`, dan kalau tebakan benar kirim `Z = z`. Verifikasi lolos padahal kita bohong — persis judulnya, "perjury". Peluang sukses per percobaan 1/5 (soundness error protokolnya 80%), sisanya tinggal reconnect.

Flag: `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}`

## Analisis

Protokol Schnorr yang benar:

```
Prover                          Verifier
  pilih r random
  R = g^r mod p          ──►
                               e random (challenge)
                        ◄──
  Z = r + e*x mod p      ──►
                               cek g^Z == R * Y^e (mod p)
```

Kalau prover jujur dan tahu `x`, persamaan selalu benar. Nah, verifier di sini cuma ngasih 5 kemungkinan `e` dan kita bisa pilih `R` dulu.

Serangan *forgery* standar untuk protokol tanpa transcript: tebak `e'`, pilih `z` random, kirim

```
R = g^z * (Y^(-e')) mod p
```

Kalau server kebetulan ngirim `e == e'`, kita balas `Z = z`. Maka:

```
g^Z = g^z
R * Y^e = g^z * Y^(-e') * Y^(e') = g^z   ✓
```

Kalau `e != e'`, verifikasi gagal dan koneksi ditutup — tinggal buka koneksi baru dan ulangi sampai beruntung. Rata-rata 5 percobaan.

Biar anti-mainstream dikit, `z` dipilih random tiap percobaan dan `P, G, Y` di-parse dari banner, jadi script tetap jalan kalau parameter instance diganti.

## Solver

```python
import re
import secrets
import socket

HOST, PORT = "165.22.100.192", <port>


def attempt():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    f = s.makefile("rb")
    buf = b""
    while b"commitment" not in buf:
        buf += f.readline()
    txt = buf.decode()
    p = int(re.search(r"p \(modulus\) is (\d+)", txt).group(1))
    g = int(re.search(r"where g is (\d+)", txt).group(1))
    y = int(re.search(r"public key is (\d+)", txt).group(1))

    guess = secrets.randbelow(5) + 1
    z = secrets.randbelow(p - 2) + 1
    r = pow(g, z, p) * pow(y, -guess, p) % p

    s.sendall(str(r).encode() + b"\n")
    buf = b""
    while b"challenge number" not in buf:
        buf += f.readline()
    e = int(re.search(r"e = (\d+)", buf.decode()).group(1))

    if e != guess:
        s.close()
        return None

    s.sendall(str(z).encode() + b"\n")
    buf = b""
    while True:
        line = f.readline()
        if not line:
            break
        buf += line
        if b"flag" in buf.lower() or b"bye" in buf.lower():
            break
    s.close()
    return buf.decode(errors="replace")


for i in range(200):
    out = attempt()
    if out is None:
        continue
    print(out.strip())
    m = re.search(r"JCC\{[^}]+\}", out)
    if m:
        print("FLAG:", m.group(0))
        break
```

```
$ python3 solve.py
Okay I'm going to verify this first...
I'm convinced! here's your flag: JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}
```

Catatan: `secrets.randbelow(5) + 1` di server bukan distribusi yang jelek, tapi **ruang sample-nya yang cuma 5** — itu sumber soundness error 1/5 yang dieksploitasi. Di protokol beneran, challenge diambil dari ruang 128-bit atau 256-bit biar peluang nebak ~0.
