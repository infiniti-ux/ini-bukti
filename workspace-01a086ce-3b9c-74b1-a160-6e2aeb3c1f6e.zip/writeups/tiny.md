# tiny

Author: UrSourceCode — Reverse — 30 solves

```
Tiny_Trace (1).tar.gz -> tinytrace.zip -> tinytrace.exe
```

## Ringkasan

`tinytrace.exe` adalah utility "maintenance console" Windows yang minta *authorization code*. Kode tidak dicek di proses utama, tapi di **proses anak** yang di-spawn sendiri dengan argumen `--worker`. Verifikasinya per karakter: 32 byte input masing-masing dicek lewat satu operasi `(X[i] ^ input[i]) + T[i] mod 256 == Y[i]`, dengan X, Y, dan T bisa diambil langsung dari binary. Tinggal dibalik jadi `input[i] = X[i] ^ ((Y[i] - T[i]) & 0xff)`.

Flag: `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}`

## Analisis

### Struktur program

Dari strings langsung kelihatan alurnya:

```
TRACE Maintenance Console
-------------------------
Authorization code:
"%s" --worker %llu %llu
TRACE: maintenance mode unlocked
TRACE: authorization rejected
```

Fungsi utama (`0x140001080`):
1. print banner + prompt `Authorization code:`
2. baca input (maks 40 byte)
3. bikin pipe, spawn diri sendiri sebagai `"%s" --worker %llu %llu"` (dengan handle pipe sebagai argumen)
4. kirim input ke worker lewat pipe
5. baca 1 byte jawaban dari worker, kalau `1` print "maintenance mode unlocked", selain itu "authorization rejected"

Fungsi worker (`0x140001480`, dijalankan kalau ada argumen `--worker`):
1. baca dari pipe sampai 0x21 byte atau EOF
2. buang `\n`/`\r` di akhir
3. kalau panjang bukan 0x20 (32), langsung tulis byte `0` dan keluar
4. kalau 32, jalankan loop verifikasi, tulis byte `1` kalau lolos

Jadi tantangannya: cari 32 byte yang bikin worker ngirim `1`.

### Loop verifikasi

Di `0x1400015f0`, setelah input 32 byte disimpan di `[rbp+0x17]`:

```asm
mov    eax, edx                      ; edx = index loop 0..0x1f
movzx  ecx, byte ptr [r8+rax+0x19340]  ; ambil dari tabel permutasi T1
movzx  eax, byte ptr [rbp+rcx-0x31]    ; X[rcx]
xor    al,  byte ptr [rbp+rcx+0x17]    ; X[rcx] ^ input[rcx]
add    al,  byte ptr [r8+rcx+0x19360]  ; + T2[rcx]
cmp    al,  byte ptr [rbp+rcx-0x11]    ; == Y[rcx] ?
jne    fail
inc    edx
cmp    edx, 0x20
jl     loop
```

Semua byte `X`, `Y` dibangun dari 16 instruksi `mov dword ptr [rbp+disp], imm32` di awal fungsi (mulai `0x140001571`), masing-masing 4 byte, total 64 byte = `X` (32 byte) + `Y` (32 byte).

- `T1` di RVA `0x19340` ternyata permutasi 0..31, jadi setiap posisi input ke-`i` kena cek tepat satu kali
- `T2` di RVA `0x19360`, isinya `13 29` berulang

Karena semua konstanta diketahui dan tiap byte cuma punya satu persamaan, solusinya unik:

```
X = 84 5b f9 9a c9 50 eb 9b 6c 81 41 56 e3 49 d9 44
    01 25 29 fd 5c da f8 41 5f 65 df c4 2e a7 83 bd
Y = e1 41 cd 0a c2 89 9a 20 6f 1f 31 8a 9e a3 99 50
    7c 3d 58 c2 16 e1 9d 9b 7e 37 c2 1d 32 f2 0a e9
T = 13 29 13 29 ...

input[i] = X[i] ^ ((Y[i] - T[i]) & 0xff)
```

Namanya "tiny" dan flag-nya `f0ll0w_7h3_ch1ld_br34kp01nt` pas — ceknya di proses anak, jadi kalau cuma nge-debug proses utama bakal muter-muter di prompt terus.

## Solver

```python
import re
import struct
import sys

d = open(sys.argv[1] if len(sys.argv) > 1 else "tinytrace.exe", "rb").read()

pe = struct.unpack_from("<I", d, 0x3c)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

t2 = d[off(0x19360):off(0x19360) + 0x20]

# 16 instruksi mov dword [rbp+disp], imm32 di worker (rva 0x1571)
code = d[off(0x1571):off(0x1571) + 0x80]
movs = re.findall(rb"\xc7\x45.(....)", code, re.S)
blob = b"".join(movs)
x, y = blob[:0x20], blob[0x20:]

flag = bytes(x[i] ^ ((y[i] - t2[i]) & 0xFF) for i in range(32))
print(flag.decode())
```

```
$ python3 solver.py tinytrace.exe
JCC{f0ll0w_7h3_ch1ld_br34kp01nt}
```
