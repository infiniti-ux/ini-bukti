# crypto-101

Author: anonymous — Kripto — 281 solves

Diberikan satu file: `flag.txt` (40 byte).

## Ringkasan

"Encoding vs encryption" — teksnya di-*encoding* pakai base64, terus di-*encrypt* (baca: digeser) pakai Caesar cipher tanpa key. Tinggal dibalik dua lapis.

Flag: `JCC{W3lc0me_T0_Cryp706r4phy}`

## Analisis

Isi `flag.txt`:

```
UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==
```

Akhiran `==` langsung nuduh base64. Decode:

```python
>>> import base64
>>> base64.b64decode("UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==")
b'QJJ{D3sj0tl_A0_Jyfw706y4wof}'
```

Format `QJJ{...}` jelas hasil geser dari `JCC{...}` — selisih 7 huruf. Berarti lapisan kedua Caesar shift −7:

```
QJJ{D3sj0tl_A0_Jyfw706y4wof}
  ↓ shift −7 (huruf saja)
JCC{W3lc0me_T0_Cryp706r4phy}
```

Cocok dengan deskripsi soalnya: base64 itu *encoding*, Caesar tanpa key itu "encryption" ala mainan — bedanya encoding bisa dibalik tanpa secret, encryption butuh key (di sini key-nya hilang, tapi shift 7 ketahuan dari prefix).

## Solver

```python
import base64
import sys

s = base64.b64decode(open(sys.argv[1] if len(sys.argv) > 1 else "flag.txt").read()).decode()

out = []
for c in s:
    if "a" <= c <= "z":
        out.append(chr((ord(c) - 97 - 7) % 26 + 97))
    elif "A" <= c <= "Z":
        out.append(chr((ord(c) - 65 - 7) % 26 + 65))
    else:
        out.append(c)
print("".join(out))
```

```
$ python3 solver.py flag.txt
JCC{W3lc0me_T0_Cryp706r4phy}
```
