REVERSE ENGINEERING
Sudoku Master
    Flag = JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}

Deskripsi:
Seseorang mengirimkan game Sudoku yang mencurigakan. Developer-nya mengklaim bahwa menyelesaikan game ini akan membuka semacam "secret reward". Langsung saja kita bedah binary-nya, siapa tau hadiah rahasianya bisa kita curi tanpa harus pintar main Sudoku.

Solusi:
File yang dikasih adalah `Sudoku.exe`, aplikasi GUI Windows. Pertama-tama aku scan string-string di dalamnya dan nemu beberapa string yang menarik perhatian:

[SS: strings output yang berisi SudokuFlagPopup, Secret Unlocked!, Secret reward unavailable, v1.3.37 (build 539)]

Ada `SudokuFlagPopup` dan `Secret Unlocked!` — ini pasti gerbang ke flag-nya. Tinggal cari di mana class window itu dibuat dan apa syaratnya.

Aku telusuri xref ke string `SudokuFlagPopup` dan ketemu fungsi yang bikin popup tersebut. Dari situ aku telusuri siapa pemanggilnya, dan ketemu satu guard yang menarik:

[SS: disassembly yang memperlihatkan cmp eax, 539h lalu jne, dan call ke fungsi reveal]

    mov eax, [skor_global]
    cmp eax, 539h        ; skor harus 0x539 alias 1337
    jne skip
    call reveal_flag     ; baru deh popup Secret Unlocked! muncul

Ternyata popup rahasia cuma muncul kalau skor final pemain tepat 1337. Wajar susah banget, main Sudoku dapat skor 1337 itu gak masuk akal. Oh iya, versi programnya "v1.3.37 (build 539)" — 539 itu 1337 dibalik, kayaknya ini sindiran biar kita nemu angkanya.

Di fungsi reveal-nya, ada 42 byte diambil dari `.rdata`, lalu diolah tiga tahap:
1. byte-nya dibalik urutannya (reverse),
2. di-xor pakai key yang dihitung dari skor: `key = (7*skor + 13) & 0xff`,
3. tiap byte di-swap nibble-nya.

[SS: disassembly / pseudo-code rantai transformasi reveal]

Dengan skor 1337, key-nya jadi `(7*1337+13) & 0xff = 0x9c`. Aku tulis solver pembaliknya:

[SS: terminal python3 solver.py Sudoku.exe yang output flag]

    $ python3 solver.py Sudoku.exe
    JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}

Hasilnya langsung keliatan valid. Aku sempat ragu antara skor 1337 atau 539 (soalnya string build-nya 539), tapi kalau pakai 539 hasilnya berantakan gak kebaca, jadi 1337 lah yang bener. Game Sudoku-nya emang cuma jebakan, flag-nya sendiri nunjukin: sudoku never give me the secret score. Beres!

solved by: <nama tim>
