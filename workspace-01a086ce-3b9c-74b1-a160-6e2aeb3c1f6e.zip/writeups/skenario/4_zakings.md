CRYPTO
Za King's Perjury
    Flag = JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}

Deskripsi:
"Sebagai seorang raja, tolong jangan pernah berbohong, memalsukan bukti, atau bersumpah palsu di atas hukum."
Challenge ini ada server-nya dan source code ikut dikasih. Judulnya "King's Perjury" — jadi sepertinya kita memang diminta bersumpah palsu, alias memalsukan bukti kriptografi di depan server.

Solusi:
Source code-nya (`server.py`) menjalankan protokol identifikasi Schnorr. Server punya bilangan prima 1024-bit `p`, generator `g = 2`, dan public key `Y = g^x mod p`. Alurnya:

[SS: potongan server.py yang berisi alur R -> e -> Z dan pengecekan pow(G,Z,P) == R*pow(Y,e,P)]

1. Kita kirim commitment `R = g^r mod p`,
2. server balas challenge `e`,
3. kita kirim `Z = r + e*x mod p`,
4. server cek `g^Z == R * Y^e (mod p)` — kalau sama, flag keluar.

Kalau kita beneran tahu secret `x`, gampang. Masalahnya kita nggak tahu `x`, dan kita disuruh "bersumpah" kalau tahu. Pas baca kodenya, ketemu kelemahan fatalnya:

[SS: highlight baris e = secrets.randbelow(5) + 1]

    e = secrets.randbelow(5) + 1

Challenge `e` cuma diambil dari {1,2,3,4,5}! Padahal di protokol yang benar, `e` harus dari ruang yang super besar biar nggak bisa ditebak. Dengan cuma 5 kemungkinan, protokol ini punya soundness error 20%.

Strateginya: tebak `e` duluan (`e'`), pilih `z` acak, dan kirim commitment palsu:

    R = g^z * Y^(-e') mod p

Kalau tebakan kita pas (server ngirim `e = e'`), kita jawab `Z = z`. Mari kita cek kenapa ini lolos:

    g^Z = g^z
    R * Y^e = g^z * Y^(-e') * Y^(e') = g^z

Verifikasi lolos sempurna padahal kita nggak pernah tahu `x` — persis judulnya, perjury! Kalau tebakan meleset, koneksi ditutup, tinggal colok ulang dan coba lagi. Rata-rata cukup 5 kali percobaan. Aku tulis script-nya:

[SS: terminal python3 solve.py yang menampilkan banner server dan flag]

    $ python3 solve.py
    welcome!
    so your public key is 2748743587820264845...
    Excellent! here's my challenge number: e = 3
    Okay I'm going to verify this first...
    I'm convinced! here's your flag: JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}

Langsung berhasil di percobaan pertama. Pelajaran dari soal ini: protokol proof-of-knowledge itu soundness-nya bergantung pada challenge yang nggak bisa ditebak. Kalau ruang challenge-nya cuma 5 nilai, bukti "saya tahu x" jadi nggak ada artinya — raja bisa aja bersumpah palsu dan nggak ketahuan.

solved by: <nama tim>
