# Skenario Writeup JCC 2026

Gaya narasi mengikuti contoh (MISC/Sanity Check). Cara pakai:
- Ganti semua `[SS: ...]` dengan screenshot asli, lalu hapus teks penandanya.
- Ganti `<nama tim>` di bagian "solved by".
- Flag sudah sesuai yang didapat waktu kualifikasi.

---

REVERSE ENGINEERING
tiny
    Flag = JCC{f0ll0w_7h3_ch1ld_br34kp01nt}

Deskripsi:
Tim monitoring kami menangkap sebuah maintenance utility yang mencurigakan pada workstation terkunci. Utility ini terus-terusan meminta "authorization code" tapi tidak pernah mau menjelaskan apa yang sebenarnya dia lindungi. Tugasnya cuma satu: bongkar binary-nya dan temukan apa yang dia sembunyikan.

Solusi:
Pertama-tama aku ekstrak dan cek file yang dikasih, ternyata isinya satu file `tinytrace.exe`, PE32+ x86-64. Langsung aku intip pakai `strings`, dan dari situ alur programnya sudah kebayang:

[SS: strings output yang ada "TRACE Maintenance Console", "Authorization code:", "maintenance mode unlocked", "authorization rejected"]

Ada beberapa string menarik: program ini bakal nge-print banner, minta authorization code, lalu ada string `"%s" --worker %llu %llu`. Dari situ aku curiga program ini menjalankan dirinya sendiri sebagai proses anak dengan argumen `--worker`.

Aku buka disassembly-nya dan ternyata tebakan aku benar. Fungsi utama cuma bertugas: print prompt, baca input, spawn proses anak `--worker`, kirim input lewat pipe, terus baca 1 byte jawaban. Kalau jawabannya `1`, muncul tulisan "maintenance mode unlocked", selain itu "authorization rejected".

[SS: disassembly fungsi utama yang menunjukkan CreateProcess/pipe atau alur spawn --worker]

Berarti verifikasi aslinya ada di proses anak! Aku lompat ke fungsi worker dan nemu loop verifikasinya:

[SS: disassembly loop verifikasi worker dengan tabel 0x19340 dan 0x19360]

Loop-nya kurang lebih gini logikanya per karakter:

    movzx ecx, byte [T1 + index]   ; tabel permutasi
    movzx eax, byte [X + rcx]      ; konstanta X
    xor   al,  input[rcx]          ; xor sama input kita
    add   al,  T2[rcx]             ; tambah konstanta T2
    cmp   al,  Y[rcx]              ; harus sama dengan konstanta Y

Konstanta X dan Y ternyata di-build di stack dari 16 instruksi `mov dword ptr [rbp+...], imm32`, jadi tinggal aku ambil 64 byte itu dari raw binary-nya. Tabel T1 adalah permutasi 0-31 dan T2 cuma pola `13 29` berulang. Karena tiap byte input kena cek tepat satu kali, persamaannya bisa langsung dibalik:

    input[i] = X[i] ^ ((Y[i] - T2[i]) & 0xff)

Aku tulis solver singkat dan langsung jalan:

[SS: terminal python3 solver.py tinytrace.exe yang output flag]

    $ python3 solver.py tinytrace.exe
    JCC{f0ll0w_7h3_ch1ld_br34kp01nt}

Ternyata kodenya cuma 32 byte dan semua persamaan cocok. Utility maintenance-nya kebuka, dan flag-nya sendiri jadi clue kenapa tadi verifikasi harus dicari di proses anak — "follow the child". Soal selesai!

solved by: <nama tim>
