CRYPTO
crypto-101
    Flag = JCC{W3lc0me_T0_Cryp706r4phy}

Deskripsi:
"Do you know what's the difference between encoding and encrypting? Why not try both? The key is missing, unfortunately."
Cuma dikasih satu file `flag.txt`, dan dari deskripsinya udah kebayang: bakal ada dua lapis — satu encoding dan satu encryption yang kunci-nya "hilang".

Solusi:
Isi `flag.txt` cuma satu baris:

[SS: terminal cat flag.txt]

    UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==

Akhiran `==` dan kumpulan karakter base64 langsung ketauan: ini base64, dan ini pasti lapisan "encoding"-nya. Aku decode:

[SS: terminal base64 decode yang hasil QJJ{D3sj0tl_A0_Jyfw706y4wof}]

    $ python3 -c "import base64; print(base64.b64decode(open('flag.txt').read()))"
    b'QJJ{D3sj0tl_A0_Jyfw706y4wof}'

Formatnya udah kaya flag (`...{...}`) tapi prefix-nya `QJJ`, bukan `JCC`. Berarti masih ada lapisan kedua — ini dia lapisan "encryption"-nya. `QJJ` ke `JCC` itu selisih 7 huruf, jadi kunci yang "hilang" itu ketebak: Caesar shift -7. Tinggal geser semua hurufnya:

[SS: terminal solver crypto yang output flag]

    $ python3 solver.py flag.txt
    JCC{W3lc0me_T0_Cryp706r4phy}

Langsung kebaca: "W3lc0me T0 Cryp706r4phy" — sambutan yang pas buat soal pertama kripto. Encoding (base64) tinggal dibalik tanpa kunci, sedangkan "encryption"-nya (Caesar) kuncinya cuma 26 kemungkinan jadi gampang ketebak dari format flag. Selesai!

solved by: <nama tim>
