# Sudoku Master

Author: UrSourceCode — Reverse — 45 solves

```
Sudoku (1).tar.gz -> Sudoku.zip -> Sudoku.exe (PE32+ GUI, x86-64)
```

## Ringkasan

Game Sudoku Windows biasa, tapi ada window class tersembunyi bernama `SudokuFlagPopup` dengan judul `Secret Unlocked!`. Fungsi yang bikin popup itu cuma kepanggil kalau pemain menyelesaikan puzzle dengan **skor final 1337 (0x539)**. Teksnya dibuat dari 42 byte ciphertext di `.rdata` dengan rantai: reverse → XOR `(7*score + 13) & 0xff` → swap nibble.

Flag: `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}`

## Analisis

### Menemukan jalur rahasia

Dari `strings` ada beberapa string menarik:

```
SudokuFlagPopup
Secret Unlocked!
Secret reward unavailable.
Puzzle completed!
Congratulations!
Rookie / Erase / Expert / Grandmaster / Solver   <- rank
v1.3.37 (build 539)
```

Fungsi `0x140001e71` melakukan setup teks rahasia lalu manggil `0x140001975` yang register window class `SudokuFlagPopup` (title `Secret Unlocked!`) plus kontrol EDIT dan tombol OK. Fungsi itu cuma dipanggil di satu tempat: `0x140001f35`, yang berada di cabang

```asm
mov eax, [0x1400092e8]      ; skor
cmp eax, 0x539              ; 1337?
jne tidak_dapat_flag
call 0x140001e71            ; reveal flag
```

Jadi game-nya sengaja dibuat mustahil/"super susah" untuk dapet skor 1337. Angka 1337 sendiri sudah diisyaratkan sama string versi `v1.3.37 (build 539)` (539 itu 1337 kelewat licik, tapi bikin ragu — nanti dibuktikan lewat hasil decode).

### Rantai transformasi (`0x140001e71`)

```asm
; copy 42 byte dari .rdata 0x6000 ke stack
loop: movzx eax, byte [0x6000 + i]
      mov   [rbp-0x60+i], al
      ...
call 0x140001d1a   ; reverse semua byte (len 0x2a)
call 0x140001d98   ; XOR tiap byte dengan key
call 0x140001e0a   ; swap nibble tiap byte
call 0x140001975   ; tampilkan di popup SudokuFlagPopup
```

Fungsi `0x140001d98` menghitung key dari skor:

```asm
mov edx, [0x1400092e8]     ; skor
mov eax, edx
shl eax, 3                 ; skor * 8
sub eax, edx               ; skor * 7
lea edx, [rax + 0xd]       ; + 13
...
; byte rendah edx dipakai sebagai key XOR
```

key = `(7 * skor + 13) & 0xff`. Dengan skor 1337: `(7*1337+13) & 0xff = 0x9c`.

Fungsi `0x140001d1a` = reverse klasik (swap dari dua ujung), `0x140001e0a` = `b = (b >> 4) | (b << 4)`.

Ciphertext di RVA `0x6000` (42 byte):

```
4bcabb9faaab69dbafbfaacaab69af1adb69ca4a69affb8fea69bbaffbaf7a69c
b2a9fdacbab2ba8a838
```

### Decode

```python
blob = bytes.fromhex("4bcabb9faaab69dbafbfaacaab69af1adb69ca4a69affb"
                     "8fea69bbaffbaf7a69cb2a9fdacbab2ba8a838")
score = 0x539
key = (7 * score + 13) & 0xff
rev = blob[::-1]
flag = bytes(((b ^ key) >> 4 | (b ^ key) << 4) & 0xff for b in rev)
print(flag.decode())
```

Hasilnya langsung keliatan valid (printable dan berformat flag):

```
JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}
```

Coba alternatif skor 539 (`key = 0xca`) menghasilkan byte tidak printable, jadi 1337 memang angka yang benar.

## Solver

```python
import struct
import sys

d = open(sys.argv[1] if len(sys.argv) > 1 else "Sudoku.exe", "rb").read()

pe = struct.unpack_from("<I", d, 0x3c)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
optsz = struct.unpack_from("<H", d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + i * 40
    _, va, rawsz, rawoff = struct.unpack_from("<IIII", d, o + 8)
    secs.append((va, rawsz, rawoff))

def off(rva):
    for va, rawsz, rawoff in secs:
        if va <= rva < va + rawsz:
            return rawoff + rva - va

blob = d[off(0x6000):off(0x6000) + 0x2a]
key = (7 * 0x539 + 13) & 0xff
rev = blob[::-1]
flag = bytes(((b ^ key) >> 4 | (b ^ key) << 4) & 0xff for b in rev)
print(flag.decode())
```

Kalau mau lihat di dalam game: tinggal patch `cmp eax, 0x539` di `0x140001f2e` jadi `jmp`, atau patch skor `[0x1400092e8]` ke 1337 sebelum menyelesaikan puzzle — popup "Secret Unlocked!" akan muncul berisi flag.
