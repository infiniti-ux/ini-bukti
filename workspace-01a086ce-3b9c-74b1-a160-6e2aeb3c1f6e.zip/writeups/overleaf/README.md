# Overleaf Writeups - JCC 2026

5 writeup siap-pakai dalam format LaTeX (pdfLaTeX) untuk Overleaf.

| File | Challenge | Kategori | Flag |
|---|---|---|---|
| `tiny.tex` | tiny | Reverse | `JCC{f0ll0w_7h3_ch1ld_br34kp01nt}` |
| `sudoku.tex` | Sudoku Master | Reverse | `JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}` |
| `crypto101.tex` | crypto-101 | Kripto | `JCC{W3lc0me_T0_Cryp706r4phy}` |
| `zaking.tex` | Za King's Perjury | Kripto | `JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}` |
| `queenannes.tex` | Queen Anne's Revenge | Pwn | `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}` |

## Cara pakai di Overleaf

1. Buka overleaf.com -> New Project -> **Blank Project** (satu project per
   writeup, atau pakai akun yang sama biar bisa collab via Share).
2. Hapus isi `main.tex`, lalu paste seluruh isi file `.tex` yang dipilih.
3. Compiler: **pdfLaTeX** (default). Simpan otomatis -> langsung compile.
4. Kalau muncul error soal `minted`/Python: klik **Menu** -> **TeX Live
   version** -> pilih versi terbaru (Overleaf akan meng-install
   pygments otomatis).
5. Export PDF: **Menu** -> **Download** -> **PDF**.

## Struktur umum tiap writeup

- Header custom + nomor halaman (x / N)
- Tabel info challenge (nama, kategori, author, solves)
- Pendahuluan + flag (kotak hijau)
- Analisis bertahap dengan listing kode / disassembly ber-warna
- Rumus matematika bernomor
- Solver script
- Kesimpulan

## Catatan

- Semua file mandiri (standalone), tidak saling `\input`, jadi aman
  dipaste satu per satu.
- Tidak ada komentar aneh di body; hanya komentar singkat di baris awal
  sebagai petunjuk penggunaan.
- Jika ingin satu PDF berisi semua writeup, gabungkan secara manual di
  Google Docs/editor setelah export, atau bilang mau dibuatkan versi
  gabungan (`main.tex` + `\input`).
