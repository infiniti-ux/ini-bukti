#!/usr/bin/env python3
"""md -> docx (subset markdown) untuk writeup JCC 2026, output siap upload Google Docs."""
import re
import sys
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FLAG_RE = re.compile(r"(JCC\{[^}]*\})")

CODE_BG = "F2F2F2"
GREEN = RGBColor(0x1E, 0x7A, 0x1E)
ACCENT = RGBColor(0x1B, 0x43, 0x69)


def set_run_font(run, name="Calibri", size=11, bold=False, italic=False, color=None):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    for a in ('w:ascii', 'w:hAnsi', 'w:cs'):
        rfonts.set(qn(a), name)


def shade_paragraph(p, fill=CODE_BG):
    ppr = p._p.get_or_add_pPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill)
    ppr.append(shd)


def add_runs_inline(p, text, base_size=11):
    """parse **bold**, *italic*, `code`, dan highlight JCC{...}"""
    tokens = re.split(r"(\*\*.+?\*\*|\*.+?\*|`.+?`|JCC\{[^}]*\})", text)
    for tok in tokens:
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**"):
            r = p.add_run(tok[2:-2]); set_run_font(r, bold=True, size=base_size)
        elif tok.startswith("`") and tok.endswith("`"):
            r = p.add_run(tok[1:-1]); set_run_font(r, name="Consolas", size=base_size - 1)
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            r = p.add_run(tok[1:-1]); set_run_font(r, italic=True, size=base_size)
        elif FLAG_RE.fullmatch(tok):
            r = p.add_run(tok); set_run_font(r, name="Consolas", size=base_size,
                                             bold=True, color=GREEN)
        else:
            # mungkin ada flag di tengah kalimat
            parts = FLAG_RE.split(tok)
            for j, seg in enumerate(parts):
                if not seg:
                    continue
                if FLAG_RE.fullmatch(seg):
                    r = p.add_run(seg); set_run_font(r, name="Consolas", size=base_size,
                                                     bold=True, color=GREEN)
                else:
                    r = p.add_run(seg); set_run_font(r, size=base_size)


def add_code_block(doc, lines, lang=""):
    for i, line in enumerate(lines):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.left_indent = Cm(0.5)
        pf.right_indent = Cm(0.3)
        pf.space_before = Pt(0 if i > 0 else 4)
        pf.space_after = Pt(0 if i < len(lines) - 1 else 6)
        shade_paragraph(p)
        r = p.add_run(line if line else " ")
        set_run_font(r, name="Consolas", size=9)


def add_table(doc, rows):
    ncol = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=ncol)
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        for j in range(ncol):
            cell = table.cell(i, j)
            txt = row[j] if j < len(row) else ""
            cell.paragraphs[0].text = ""
            p = cell.paragraphs[0]
            add_runs_inline(p, txt, base_size=10)
            if i == 0:
                for r in p.runs:
                    r.font.bold = True
    return table


def md_to_docx(md_text, doc):
    lines = md_text.split("\n")
    i = 0
    in_code = False
    code_buf = []
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if in_code:
            if stripped.startswith("```"):
                add_code_block(doc, code_buf)
                code_buf, in_code = [], False
            else:
                code_buf.append(line)
            i += 1
            continue
        if stripped.startswith("```"):
            in_code = True
            code_buf = []
            i += 1
            continue

        # tabel
        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|[\s:\-|]+\|\s*$", lines[i + 1]):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not re.match(r"^[\s:\-|]+$", "|".join(cells)):
                    rows.append(cells)
                i += 1
            if rows:
                add_table(doc, rows)
            doc.add_paragraph()
            continue

        # heading
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level = len(m.group(1))
            text = m.group(2).replace("`", "")
            if level == 1:
                p = doc.add_heading(level=1)
                r = p.add_run(text)
                set_run_font(r, size=20, bold=True, color=ACCENT)
            elif level == 2:
                p = doc.add_heading(level=2)
                r = p.add_run(text)
                set_run_font(r, size=15, bold=True, color=ACCENT)
            else:
                p = doc.add_heading(level=min(level, 4))
                r = p.add_run(text)
                set_run_font(r, size=12, bold=True)
            i += 1
            continue

        # bullet / list
        m = re.match(r"^(\s*)[-*+]\s+(.*)$", line)
        if m:
            p = doc.add_paragraph(style="List Bullet")
            add_runs_inline(p, m.group(2))
            i += 1
            continue
        m = re.match(r"^(\s*)\d+[.)]\s+(.*)$", line)
        if m:
            p = doc.add_paragraph(style="List Number")
            add_runs_inline(p, m.group(2))
            i += 1
            continue

        # blockquote
        if stripped.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.75)
            add_runs_inline(p, stripped.lstrip("> ").strip(), base_size=11)
            for r in p.runs:
                r.font.italic = True
                r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            i += 1
            continue

        # horizontal rule / kosong
        if re.match(r"^\s*-{3,}\s*$", line) or stripped == "":
            if stripped == "":
                i += 1
                continue
            i += 1
            continue

        # paragraf biasa
        p = doc.add_paragraph()
        add_runs_inline(p, stripped)
        i += 1


def build_cover(doc):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("JCC 2026"); set_run_font(r, size=44, bold=True, color=ACCENT)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("KUMPULAN WRITEUP"); set_run_font(r, size=26, bold=True, color=ACCENT)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Kualifikasi Jejepangan Cyber Challenge 2026"); set_run_font(r, size=14, italic=True)
    for _ in range(3):
        doc.add_paragraph()
    for label in ["Tim : <NAMA TIM>", "Anggota : <NAMA ANGGOTA>", "Kategori : Reverse Engineering / Kriptografi / Pwn"]:
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(label); set_run_font(r, size=13)
    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("9 September 2026"); set_run_font(r, size=12, italic=True)


def build_toc(doc, items):
    doc.add_page_break()
    p = doc.add_paragraph()
    r = p.add_run("Daftar Isi"); set_run_font(r, size=18, bold=True, color=ACCENT)
    for name, cat, flag in items:
        p = doc.add_paragraph()
        add_runs_inline(p, f"{name}  —  {cat}")
    doc.add_paragraph()


def main():
    src = {
        "tiny.tex": ("1. tiny (Reverse)", None),
    }
    order = [
        ("/home/user/writeups/tiny.md", "tiny", "Reverse Engineering"),
        ("/home/user/writeups/sudoku.md", "Sudoku Master", "Reverse Engineering"),
        ("/home/user/writeups/crypto-101.md", "crypto-101", "Kriptografi"),
        ("/home/user/writeups/za-kings-perjury.md", "Za King's Perjury", "Kriptografi"),
        ("/home/user/writeups/queen-annes-revenge.md", "Queen Anne's Revenge", "Pwn"),
    ]
    doc = Document()
    # margin & default style
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.2)
        section.right_margin = Cm(2.2)
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    build_cover(doc)
    build_toc(doc, order)

    first = True
    for path, name, cat in order:
        md = open(path, encoding="utf-8").read()
        if not first:
            doc.add_page_break()
        first = False
        # judul tiap file (#) -> otomatis jadi heading level 1 oleh parser
        md_to_docx(md, doc)

    out = "/home/user/writeups/Writeup_JCC2026.docx"
    doc.save(out)
    print("saved", out)


if __name__ == "__main__":
    main()
