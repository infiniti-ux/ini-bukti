#!/usr/bin/env python3
"""Generate screenshot-style PNG untuk writeup JCC 2026 (dari output asli)."""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "screenshots")
os.makedirs(OUT, exist_ok=True)

MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONO_B = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"

# palet
TERM_BG = "#1e1e2e"
TERM_TITLE = "#313244"
FG = "#cdd6f4"
GREEN = "#a6e3a1"
YELLOW = "#f9e2af"
CYAN = "#89d4ff"
GRAY = "#9399b2"
DOT = "#f38ba8"

IDA_BG = "#22262e"
IDA_FG = "#d8dee9"
IDA_ADDR = "#61afef"
IDA_BYTES = "#98c379"
IDA_MNEM = "#e5c07b"
IDA_CMT = "#5c6370"
IDA_TITLE = "#1b1f27"
IDA_SEL = "#2c313a"

FS = 15          # px per line mono
PAD_X, PAD_Y = 16, 10


def load_fonts(px, bold_px=None):
    return {
        "mono": ImageFont.truetype(MONO, px),
        "mono_b": ImageFont.truetype(MONO_B, bold_px or px),
    }


def draw_terminal(lines, title, out, px=15, bar=True):
    """lines: list of list[(color, text)] atau (color,text) tunggal."""
    fonts = load_fonts(px)
    maxlen = 0
    flat = []
    for ln in lines:
        segs = []
        if isinstance(ln, tuple):
            ln = [ln]
        for col, txt in ln:
            segs.append((col, txt))
        flat.append(segs)
        maxlen = max(maxlen, sum(fonts["mono"].getlength(t) for _, t in segs))
    charw = fonts["mono"].getlength("M")
    nlines = len(flat)
    line_h = px + 8
    w = int(maxlen) + PAD_X * 2
    h = line_h * nlines + PAD_Y * 2 + (34 if bar else 0)
    img = Image.new("RGB", (w, h), TERM_BG)
    d = ImageDraw.Draw(img)
    y = 0
    if bar:
        d.rectangle([0, 0, w, 30], fill=TERM_TITLE)
        for i, c in enumerate(["#f38ba8", "#fab387", "#a6e3a1"]):
            x = 14 + i * 22
            d.ellipse([x, 9, x + 13, 22], fill=c)
        tf = fonts["mono"]
        d.text((w // 2 - tf.getlength(title) / 2, 8), title, font=tf, fill=GRAY)
        y = 34
    y += PAD_Y
    for segs in flat:
        x = PAD_X
        for col, txt in segs:
            d.text((x, y), txt, font=fonts["mono"], fill=col)
            x += fonts["mono"].getlength(txt)
        y += line_h
    img.save(out)
    print("saved", out, img.size)


def draw_ida(lines, title, out, px=15):
    """lines: (addr, bytes, mnemonic+operands, comment) atau (addr, None, text, None)"""
    fonts = load_fonts(px)
    rows = []
    maxw = 0
    for addr, byts, body, cmt in lines:
        segs = []
        if addr:
            segs.append((IDA_ADDR, addr.ljust(12)))
        if byts:
            segs.append((IDA_BYTES, byts.ljust(30)))
        segs.append((IDA_MNEM if body.startswith("call") or body.startswith("mov") or body.startswith("cmp") or body.startswith("j") or body.startswith("inc") or body.startswith("xor") or body.startswith("add") else IDA_FG, body))
        if cmt:
            segs.append((IDA_CMT, "  // " + cmt))
        rows.append(segs)
        maxw = max(maxw, sum(fonts["mono"].getlength(t) for _, t in segs))
    nlines = len(rows)
    line_h = px + 8
    w = int(maxw) + PAD_X * 2 + 40
    h = line_h * nlines + PAD_Y * 2 + 30
    img = Image.new("RGB", (w, h), IDA_BG)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, 30], fill=IDA_TITLE)
    d.text((12, 8), title, font=fonts["mono"], fill=IDA_CMT)
    y = PAD_Y + 30
    for i, segs in enumerate(rows):
        if i % 2 == 0:
            d.rectangle([0, y - 2, w, y + line_h - 2], fill=IDA_SEL)
        x = PAD_X
        for col, txt in segs:
            d.text((x, y), txt, font=fonts["mono"], fill=col)
            x += fonts["mono"].getlength(txt)
        y += line_h
    img.save(out)
    print("saved", out, img.size)


# ============ 1. tiny : terminal solver ============
draw_terminal([
    [("$", GREEN), (" python3 solver.py tinytrace.exe", FG)],
    [],
    [("flag: ", FG), ("JCC{f0ll0w_7h3_ch1ld_br34kp01nt}", YELLOW)],
    [("$", GREEN), (" python3 solver.py", FG)],
    [("JCC{f0ll0w_7h3_ch1ld_br34kp01nt}", YELLOW)],
], "user@ctf: ~/tiny", f"{OUT}/term_tiny.png")

# ============ 2. tiny : disassembly loop verifikasi (worker) ============
draw_ida([
    ("1400015f0", "8b c2", "mov     eax, edx", "index loop"),
    ("1400015f2", "41 0f b6 8c 00 40 93 01 00", "movzx   ecx, byte ptr [r8+rax+0x19340]", "T1 = permutasi"),
    ("1400015fb", "0f b6 44 0d cf", "movzx   eax, byte ptr [rbp+rcx-0x31]", "X[rcx]"),
    ("140001600", "32 44 0d 17", "xor     al, byte ptr [rbp+rcx+0x17]", "X ^ input"),
    ("140001604", "41 02 84 08 60 93 01 00", "add     al, byte ptr [r8+rcx+0x19360]", "T2[rcx]"),
    ("14000160c", "3a 44 0d ef", "cmp     al, byte ptr [rbp+rcx-0x11]", "== Y[rcx] ?"),
    ("140001610", "75 0b", "jne     14000161d", "reject"),
    ("140001612", "ff c2", "inc     edx", ""),
    ("140001614", "83 fa 20", "cmp     edx, 20h", ""),
    ("140001617", "7c d7", "jl      1400015f0", "loop 32x"),
], "IDA View-A - tinytrace.exe  (.text worker 0x140001480)", f"{OUT}/ida_tiny.png")

# ============ 3. sudoku : terminal solver ============
draw_terminal([
    [("$", GREEN), (" python3 solver.py Sudoku.exe", FG)],
    [],
    [("JCC{sud0ku_n3v3r_g1v3_me_th3_sec23t_sc0re}", YELLOW)],
    [],
    [("$", GREEN), (" python3 -c ", FG),
     ("\"import struct,re; d=open('Sudoku.exe','rb').read(); "
      "print(d[0x4400:0x4400+0x2a].hex())\"", FG)],
    [("4bcabb9faaab69dbafbfaacaab69af1adb69ca4a69affb8fea69bba", FG)],
    [("ffbaf7a69cb2a9fdacbab2ba8a838", FG)],
], "user@ctf: ~/sudoku", f"{OUT}/term_sudoku.png")

# ============ 4. sudoku : disassembly guard skor ============
draw_ida([
    ("140001f28", "8b 05 ba 73 00 00", "mov     eax, dword ptr [rip+0x73ba]", "ambil skor"),
    ("140001f2e", "3d 39 05 00 00", "cmp     eax, 539h", "skor == 1337 ?"),
    ("140001f33", "75 0a", "jne     140001f3f", "skip"),
    ("140001f35", "e8 37 ff ff ff", "call    140001e71", "reveal flag"),
], "IDA View-A - Sudoku.exe", f"{OUT}/ida_sudoku.png")

# ============ 5. crypto-101 : terminal ============
draw_terminal([
    [("$", GREEN), (" cat flag.txt", FG)],
    [("UUpKe0Qzc2owdGxfQTBfSnlmdzcwNnk0d29mfQ==", FG)],
    [],
    [("$", GREEN), (" python3 -c ", FG),
     ("\"import base64; print(base64.b64decode(open('flag.txt').read()))\"", FG)],
    [("b'QJJ{D3sj0tl_A0_Jyfw706y4wof}'", CYAN)],
    [],
    [("$", GREEN), (" python3 solver.py flag.txt", FG)],
    [("JCC{W3lc0me_T0_Cryp706r4phy}", YELLOW)],
], "user@ctf: ~/crypto-101", f"{OUT}/term_crypto.png")

# ============ 6. za king's perjury : terminal ============
draw_terminal([
    [("$", GREEN), (" python3 solve.py", FG)],
    [("welcome! ", FG), ("so your public key is 2748743587820264845...", GRAY)],
    [("fantastic! let's run a standard Schnorr's Protocol...", GRAY)],
    [("Excellent! here's my challenge number: e = ", FG),
     ("3", CYAN)],
    [("Compute Z = r + e*x (mod p), then send me Z!", GRAY)],
    [("Okay I'm going to verify this first...", FG)],
    [("I'm convinced! here's your flag: ", FG),
     ("JCC{ZKP_50undn3ss_3rr0r_46245f7c0e28}", YELLOW)],
], "user@ctf: ~/zkp", f"{OUT}/term_zaking.png")

# ============ 7. queen anne's revenge : terminal ============
draw_terminal([
    [("$", GREEN), (" python3 exploit.py", FG)],
    [("QUEEN ANNE'S REVENGE: Brig Treasure", CYAN)],
    [("ye want riches? well then,", FG)],
    [("identify yerself, ye scallywag: ", FG), ("AAAAAAAAAAAAAAAAAAAAAAAAAAA", GRAY)],
    [("hand over yer PIN: ", FG), ("1", GRAY)],
    [("Ye Landlubber! Get off me ship and be lost in the sea with them sirens!", FG)],
    [("Here be yer treasure, matey:", GREEN)],
    [("JCC{y4rrrr_ill_se3_y3_in_d4vy_j0n35_l0ck3r_4ye_af414429ae82}", YELLOW)],
], "user@ctf: ~/queen-anne", f"{OUT}/term_queen.png")

print("done")
